# A 14-symbol superpermutation of length 93,904,705,099

Jaehun Jung · 25 November 2026

This word saves **185 letters** over Jakub Halfar’s W-0171, which has length 93,904,705,284. It saves 163 more letters than our earlier 22-letter improvement. The decoded word contains all 87,178,291,200 permutations of the fourteen symbols. [Source W-0171](https://superpermutations.com/w/W-0171)

[Candidate word](W-0171-minus-185.detour) · [Cut certificate](patch.tsv) · [Verification output](verification.log)

## Construction

The certificate cuts W-0171 at 930 transitions between consecutive permutation windows. Each of the resulting 931 pieces contains both its boundary windows. The checker reads the original letters at each cut and confirms that no additional permutation starts between those two windows. Every permutation in W-0171 therefore lies entirely inside a retained piece.

We searched over the order of the pieces and the windows at which they join. Moving the beginning of a piece to an internal cut, or moving its end to one, allows two different suffixes and prefixes to meet. We evaluated these changes alongside directed traveling-salesman tours and used subset dynamic programming to refine selected groups. The final certificate expresses every change as a single reordering of original pieces. The sum of overlaps rises from 5,174 to 5,359 letters. The difference gives the 185-letter saving. The search used a public implementation of LKH. [LKH implementation](https://github.com/c4v4/LKH3)

The first permutation after reordering was `2D3C71890B465A`. A single bijection of the alphabet maps it to `0123456789ABCD` throughout the word. This preserves length and permutation coverage and gives the first window required by the Almanac. [Submission format](https://superpermutations.com/docs/words)

## Verification

| Quantity | Result |
| --- | ---: |
| Decoded length | 93,904,705,099 |
| Distinct permutations | 87,178,291,200 |
| Missing permutations | 0 |
| Extra occurrences of permutations | 61 |
| Windows that are not permutations | 6,726,413,825 |

The independent coverage pass groups windows by circular rotation, marks classes containing all fourteen rotations in default blocks, and collects the individual rotations of the remaining classes. The package also verifies that undoing the alphabet bijection recovers the exact word certified by the cut list.

Extract the verification ZIP and run the following command from its directory.

```sh
python3 verify.py
```

To rebuild the word from W-0171 and the cut list in the same run, provide a new output filename.

```sh
python3 verify.py --rebuild rebuilt.detour
```

The verifier uses Python 3 with LZMA support, a C++17 compiler and temporary disk space. Linux also requires OpenSSL development headers and its crypto library. The decoded 93.9 GB word is streamed.

| SHA-256 | Digest |
| --- | --- |
| Uploaded Detour file | `4be001ace93a7a6284adedad2898552280b1aa0e443b2eb4217d34431ab3b9cd` |
| Decoded word starting with the identity | `015f5408455202a7aa7667472b84c901200cf4168b849f3571c58fde3f8c0ffc` |
| Reordered word before relabeling | `8a149b7a88b1fec65f1c36dbde9fcdff46c17ac69a2a479ed96db3a988c4b622` |

Jakub Halfar constructed W-0171. Jaehun Jung directed this follow-up search. OpenAI Codex implemented the search, assembled the word and ran the computational checks. The original and adapted word data are distributed under Creative Commons Attribution 4.0. [Original record](https://superpermutations.com/w/W-0171) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
