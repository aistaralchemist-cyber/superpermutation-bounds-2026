// Canonical Detour v1 representation of this 14-symbol word.
// Split explicit transitions at all valid intermediate windows, then follow
// the encoder's default-step and maximal-detour rules. Runs which begin at
// a reset can be copied as counts without visiting their individual steps.
#include "detour14.hpp"
#include <numeric>
struct Step { int weight; U code; };

struct Canonical {
    Record& input;
    std::ofstream out;
    U defaults = 0, pending = 0;
    int pendingWeight = 0;
    std::array<U, N+1> prefix{}, level{};
    std::array<std::vector<Step>,128> small;
    std::unordered_map<U, std::vector<Step>> large;

    Canonical(Record &in, const char *path) : input(in), out(path,std::ios::binary) {
        U width = 1, first = 3;
        for(int d=1;d<=N;d++) {
            width *= N+1-d;
            level[d]=width;
            prefix[d]=first;
            first+=input.fact[d];
        }
        check(bool(out),"open output");
    }
    int expected(U pos) const {
        int d=1;
        while(d<=N && (pos+1)%level[d]==0) ++d;
        return d;
    }
    void var(U value) {
        while(value>=128) {out.put((value&127)|128);value>>=7;}
        out.put(value);
    }
    U rankCode(const Byte *from, const Byte *added, int k) const {
        std::array<Byte,N> choices{};
        std::reverse_copy(from,from+k,choices.begin());
        U code=prefix[k];
        for(int j=0;j<k;j++) {
            int count=k-j;
            auto end=choices.begin()+count;
            auto it=std::find(choices.begin(),end,added[j]);
            check(it!=end,"invalid emitted permutation");
            code+=(it-choices.begin())*input.fact[count-1];
            std::move(it+1,end,it);
        }
        return code;
    }
    void flush() {
        if(!pendingWeight) return;
        var(defaults);var(pending);
        defaults=0;pending=0;pendingWeight=0;
    }
    void add(int k, U code) {
        if(pendingWeight) {
            if(k>=2 && pendingWeight+k<=N) {
                const auto& a=input.event(pending);
                const auto& b=input.event(code);
                std::array<Byte,N> appended{}, identity{};
                std::iota(identity.begin(),identity.end(),0);
                std::copy_n(a.additions.data(),pendingWeight,appended.begin());
                for(int j=0;j<k;j++) appended[pendingWeight+j]=a.perm[b.additions[j]];
                pendingWeight+=k;
                pending=rankCode(identity.data(),appended.data(),pendingWeight);
                return;
            }
            flush();
        }
        if(code==prefix[k] && expected(defaults)==k) ++defaults;
        else {pendingWeight=k;pending=code;}
    }
    void run(U g) {
        if(!g) return;
        if(pendingWeight) flush(); // The first incoming default is always of weight one.
        if(!defaults) {defaults=g;return;}
        for(U i=0;i<g;i++) {int k=expected(i);add(k,prefix[k]);}
    }
    const std::vector<Step>& split(U code) {
        auto& result= code<small.size()?small[code]:large[code];
        if(!result.empty()) return result;
        const auto& e=input.event(code);
        std::array<Byte,N> current{},last{};
        std::iota(current.begin(),current.end(),0);
        last=current;
        int start=0;
        for(int j=0;j<e.k;j++) {
            std::rotate(current.begin(),current.begin()+1,current.end());
            current.back()=e.additions[j];
            unsigned mask=0;
            for(Byte z:current) mask|=1u<<z;
            if(mask!=((1u<<N)-1)) continue;
            int k=j+1-start;
            result.push_back({k,rankCode(last.data(),e.additions.data()+start,k)});
            last=current;start=j+1;
        }
        check(start==e.k,"no final permutation");
        return result;
    }
    void write() {
        size_t pos=22;
        out.write(reinterpret_cast<const char*>(input.ptr),22);
        check(input.read(pos)==0 && input.read(pos)==1,"initial START required");
        var(0);var(1);out.write(reinterpret_cast<const char*>(input.ptr+pos),N);pos+=N;
        while(true) {
            U g=input.read(pos), code=input.read(pos);
            run(g);
            if(!code) break;
            check(code>=3,"only steps may follow the initial START");
            for(const auto& s:split(code)) add(s.weight,s.code);
        }
        flush();var(defaults);var(0);
        check(pos+32==input.bytes,"bad trailer size");
        out.write(reinterpret_cast<const char*>(input.ptr+pos),32);
        out.close();check(bool(out),"write failed");
    }
};
int main(int argc,char**argv) {
    try {
        check(argc==3,"usage: canonicalize INPUT.tokens OUTPUT.tokens");
        Record r(argv[1]);
        Canonical encoder(r,argv[2]);encoder.write();
    } catch(const std::exception &e) {std::cerr<<e.what()<<'\n';return 1;}
}
