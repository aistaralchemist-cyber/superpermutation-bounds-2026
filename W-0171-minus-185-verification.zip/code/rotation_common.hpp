#pragma once
#include "detour14.hpp"
#include <numeric>
struct Intermediate {
  State relative;
  int gap;
};

// Lexicographic rank among the permutations of {0,...,12}.
U rank13(const Byte *word) {
  U rank = 0;
  unsigned unused = (1u << 13) - 1;
  for (int i = 0; i < 12; ++i) {
    unsigned bit = 1u << word[i];
    rank = rank * (13 - i) + __builtin_popcount(unused & (bit - 1));
    unused ^= bit;
  }
  return rank;
}


// At a detour of at most 14 letters, inspect every intervening raw window.
std::vector<Intermediate> intermediate(const Event &event) {
  State current;
  std::iota(current.s.begin(), current.s.end(), 0);
  int last = 0;
  std::vector<Intermediate> result;
  for (int i = 0; i < event.k; ++i) {
    std::rotate(current.s.begin(), current.s.begin() + 1,
                current.s.begin() + N);
    current.s[N - 1] = event.additions[i];
    unsigned present = 0;
    for (int j = 0; j < N; ++j)
      present |= 1u << current.s[j];
    if (present == (1u << N) - 1) {
      result.push_back({current, i + 1 - last});
      last = i + 1;
    }
  }
  return result;
}

