#include "detour14.hpp"
// The source has valid boundary permutations over the ranges recoded below, with
// steps. At each interior token boundary the current permutation is valid.
// Recode the boundary bytes of each selected substring; copy its interior
// token stream under the original boundary permutation.
struct Writer {
  std::ofstream out;
  explicit Writer(const char *p) : out(p,std::ios::binary) {check(bool(out),"open output");}
  void raw(const void *p,size_t n){out.write((const char*)p,n);check(bool(out),"output failure");}
  void var(U v){while(v>=128){Byte b=(v&127)|128;raw(&b,1);v>>=7;}Byte b=v;raw(&b,1);}
  void literal(const std::string&s){if(s.size()){var(0);var(2);var(s.size());raw(s.data(),s.size());}}
  void start(const State& env){var(0);var(1);raw(env.s.data(),14);}
};
bool valid(const std::string& p){std::string s=p;std::sort(s.begin(),s.end());return s=="0123456789ABCD";}
void step(Writer& w,Record &r,const std::string &p,const std::string &q,int k){
  if(k==0){check(p==q,"mismatch when no letters appended");return;}
  check(1<=k&&k<=14&&p.substr(k)==q.substr(0,14-k),"invalid explicit step");
  U code=3;for(int i=1;i<k;i++)code+=r.fact[i];
  std::string a=p.substr(0,k);std::reverse(a.begin(),a.end());
  for(int j=14-k;j<14;j++){auto idx=a.find(q[j]);check(idx!=a.npos,"unexpected step");code+=idx*r.fact[13-j];a.erase(idx,1);}
  w.var(0);w.var(code);
}
void interval(Writer& w,Record &r,U lo,U hi){
  auto raw=r.str(lo,hi);check(raw.size()>=14,"short interval");
  auto p=raw.substr(0,14);check(valid(p),"invalid beginning in recode");size_t old=0;
  for(size_t i=1;i+14<=raw.size();i++){auto q=raw.substr(i,14);if(valid(q)){step(w,r,p,q,i-old);p=q;old=i;}}
  check(old+14==raw.size(),"invalid ending in recode");
}
Cursor before(Record &r,U x){
  auto it=std::upper_bound(r.index.begin(),r.index.end(),x,[](U pos,const Cursor &c){return pos<c.offset;});
  check(it!=r.index.begin(),"no earlier token boundary");
  Cursor c=*std::prev(it);
  while(c.offset<x){auto q=c;if(!r.advance(q,0,0,nullptr)||q.offset>x)break;c=q;}return c;
}
int main(int argc,char**argv){try{
 check(argc==4,"expected source uncompressed tokens, checked TSV patch, output tokens");
 Record r(argv[1]);
 check(r.length==93904705284ULL && r.trailer=="a369344aa9c7e68331e1b471f51b99d20fb0e9b0954d56b0a8f002a05ca3820c","wrong source");
 std::ifstream f(argv[2]);int m;U n;f>>m>>n;
 std::vector<U> starts{0},ends;for(int i=0;i<m;i++){U p,g;std::string a,b;f>>p>>g>>a>>b;starts.push_back(p+g);ends.push_back(p+14);}
 ends.push_back(r.length);std::vector<int> order(m+1),ov(m+1);for(auto&v:order)f>>v;for(int i=1;i<=m;i++)f>>ov[i];check(bool(f),"bad patch");
 Writer w(argv[3]);w.raw(r.ptr,22);Sink hash(true);std::string prev;
 for(int i=0;i<=m;i++){
  auto id=order[i];U lo=starts[id]+ov[i],hi=ends[id];check(lo<=hi&&hi<=r.length,"range error");
  U start=starts[id];auto p=r.str(start,start+14);
  if(i==0){w.var(0);w.var(1);w.raw(p.data(),14);}else step(w,r,prev,p,14-ov[i]);
  auto last=before(r,hi);
  if(last.offset<start+14)interval(w,r,start,hi);
  else {
   auto first=before(r,start+14);
   if(first.offset<start+14)check(r.advance(first,0,0,nullptr),"missing anchor");
   check(start+14<=first.offset&&first.offset<=last.offset&&first.token<=last.token,"anchor fault");
   interval(w,r,start,first.offset);
   w.raw(r.ptr+first.token,last.token-first.token);
   interval(w,r,last.offset-14,hi);
  }
  prev=r.str(hi-14,hi);
  r.slice(lo,hi,hash);
 }
 check(hash.count==n,"length error");
 auto h=hash.digest();w.var(0);w.var(0);for(int i=0;i<64;i+=2){Byte b=std::stoi(h.substr(i,2),nullptr,16);w.raw(&b,1);}
 std::cout<<"word length "<<n<<" sha256 "<<h<<std::endl;
 return 0;
 }catch(const std::exception &e){std::cerr<<e.what()<<std::endl;return 1;}}
