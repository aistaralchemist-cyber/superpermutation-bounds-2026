#pragma once
// Detour v1 decoder for the 14-letter alphabet.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <unordered_map>
#include <vector>
#if defined(__aarch64__)
#include <arm_neon.h>
#endif
#if defined(__APPLE__)
#include <CommonCrypto/CommonDigest.h>
using SHAContext = CC_SHA256_CTX;
#define hash_init CC_SHA256_Init
#define hash_update CC_SHA256_Update
#define hash_final CC_SHA256_Final
#else
#include <openssl/sha.h>
using SHAContext = SHA256_CTX;
#define hash_init SHA256_Init
#define hash_update SHA256_Update
#define hash_final SHA256_Final
#endif
using Byte = uint8_t;
using U = uint64_t;
constexpr int N = 14;
void check(bool ok, const char *msg) {
  if (!ok)
    throw std::runtime_error(msg);
}
struct State {
  std::array<Byte, 16> s{};
};
void mapbytes(const State &env, const Byte *in, Byte *out, size_t len) {
#if defined(__aarch64__)
  auto t = vld1q_u8(env.s.data());
  for (; len >= 16; len -= 16, in += 16, out += 16)
    vst1q_u8(out, vqtbl1q_u8(t, vld1q_u8(in)));
#endif
  for (; len; len--)
    *out++ = env.s[*in++];
}
State mapped(const State &e, const Byte *p) {
  State z;
#if defined(__aarch64__)
  vst1q_u8(z.s.data(), vqtbl1q_u8(vld1q_u8(e.s.data()), vld1q_u8(p)));
#else
  mapbytes(e, p, z.s.data(), N);
#endif
  return z;
}
std::string hex(const Byte *p, size_t k) {
  std::ostringstream out;
  for (size_t i = 0; i < k; i++)
    out << std::hex << std::setw(2) << std::setfill('0') << int(p[i]);
  return out.str();
}
struct Sink {
  bool hashing;
  SHAContext sha;
  std::array<Byte, 131072> buf{};
  size_t used = 0;
  std::string data;
  U count = 0;
  explicit Sink(bool h) : hashing(h) {
    if (h)
      hash_init(&sha);
  }
  void put(const State *e, const Byte *p, size_t n) {
    count += n;
    if (!hashing) {
      auto k = data.size();
      data.resize(k + n);
      if (e)
        mapbytes(*e, p, (Byte *)data.data() + k, n);
      else
        std::memcpy(data.data() + k, p, n);
      return;
    }
    while (n) {
      size_t k = std::min(n, buf.size() - used);
      if (e)
        mapbytes(*e, p, buf.data() + used, k);
      else
        std::memcpy(buf.data() + used, p, k);
      used += k;
      n -= k;
      p += k;
      if (used == buf.size()) {
        hash_update(&sha, buf.data(), used);
        used = 0;
      }
    }
  }
  std::string digest() {
    if (used)
      hash_update(&sha, buf.data(), used);
    Byte d[32];
    hash_final(d, &sha);
    return hex(d, 32);
  }
};
struct Event {
  uint8_t k = 0;
  std::array<Byte, 16> additions{}, perm{};
};
struct Cursor {
  size_t token = 22;
  U offset = 0;
  State env;
};
struct Record {
  const Byte *ptr;
  size_t bytes;
  std::vector<Cursor> index;
  std::vector<Byte> templ;
  std::vector<uint32_t> costs;
  std::array<U, N + 1> fact{};
  std::array<Event, 2048> small{};
  std::unordered_map<U, Event> big;
  U length = 0;
  std::string trailer;
  explicit Record(const char *path) {
    int fd = open(path, O_RDONLY);
    check(fd >= 0, "cannot open token file");
    struct stat st;
    check(!fstat(fd, &st), "stat failed");
    bytes = st.st_size;
    ptr = (Byte *)mmap(nullptr, bytes, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    check(ptr != MAP_FAILED, "mmap failed");
    check(bytes > 50 && !memcmp(ptr,
                                "Detour\1\16"
                                "0123456789ABCD",
                                22),
          "mismatched 14-symbol alphabet/header");
    fact[0] = 1;
    for (int i = 1; i <= N; i++)
      fact[i] = fact[i - 1] * i;
    // For a fresh default block both its letters and its terminal permutation
    // are prefixes/slices of a single recursive word in the initial alphabet.
    for (int i = 0; i < N; i++)
      templ.push_back(i);
    costs.push_back(0);
    size_t pos = 22;
    U maxg = 0;
    bool has_window = false;
    for (;;) {
      U g = read(pos), c = read(pos);
      check(has_window || g == 0, "default steps without a window");
      maxg = std::max(maxg, g);
      if (!c) {
        check(pos + 32 == bytes, "bad trailer position");
        trailer = hex(ptr + pos, 32);
        break;
      }
      if (c == 1) {
        check(bytes - pos >= N, "truncated START");
        std::string window((const char *)ptr + pos, N);
        std::sort(window.begin(), window.end());
        check(window == "0123456789ABCD", "invalid START permutation");
        pos += N;
        has_window = true;
      } else if (c == 2) {
        auto l = read(pos);
        check(l > 0 && l <= bytes - pos, "bad literal length");
        pos += l;
        has_window = false;
      } else {
        check(has_window, "step outside a window");
      }
    }
    check(maxg < 10000000, "default block exceeds this verifier’s template limit");
    for (U t = 1; t <= maxg; t++) {
      U a = t;
      int d = 1;
      while (!(a % (N + 1 - d))) {
        a /= N + 1 - d;
        d++;
      }
      auto begin = templ.size() - N;
      for (int j = d - 1; j >= 0; j--)
        templ.push_back(templ[begin + j]);
      costs.push_back(templ.size() - N);
    }
    templ.resize(templ.size() + 16, 0);
    Cursor cur;
    U tokens = 0;
    for (;;) {
      if (!(tokens % 1024))
        index.push_back(cur);
      if (!advance(cur, 0, 0, nullptr))
        break;
      tokens++;
    }
    length = cur.offset;
  }
  U read(size_t &pos) const {
    U v = 0;
    for (int shift = 0; shift < 63; shift += 7) {
      check(pos < bytes, "truncated varint");
      auto b = ptr[pos++];
      v |= U(b & 127) << shift;
      if (b < 128)
        return v;
    }
    throw std::runtime_error("varint overflow");
  }
  const Event &event(U code) {
    Event *e = code < small.size() ? &small[code] : &big[code];
    if (e->k)
      return *e;
    U r = code - 3;
    int k = 1;
    while (k <= N && r >= fact[k])
      r -= fact[k++];
    check(k <= N, "bad detour rank");
    e->k = k;
    std::vector<Byte> avail;
    for (int i = k - 1; i >= 0; i--)
      avail.push_back(i);
    for (int i = 0; i < k; i++) {
      auto j = r / fact[k - 1 - i];
      r %= fact[k - 1 - i];
      e->additions[i] = avail[j];
      avail.erase(avail.begin() + j);
    }
    for (int i = k; i < N; i++)
      e->perm[i - k] = i;
    std::copy_n(e->additions.begin(), k, e->perm.begin() + N - k);
    return *e;
  }
  // Append, possibly intersecting the requested raw interval.
  void emit(Cursor &c, const State *env, const Byte *p, size_t n, U lo, U hi,
            Sink *out) {
    if (out && c.offset < hi && lo < c.offset + n) {
      auto begin = std::max(c.offset, lo) - c.offset;
      auto end = std::min(c.offset + n, hi) - c.offset;
      out->put(env, p + begin, end - begin);
    }
    c.offset += n;
  }
  bool advance(Cursor &c, U lo, U hi, Sink *out) {
    U g = read(c.token), code = read(c.token);
    auto z = costs[g];
    if (z) {
      emit(c, &c.env, templ.data() + N, z, lo, hi, out);
      c.env = mapped(c.env, templ.data() + z);
    }
    if (code == 0)
      return false;
    if (code == 1) {
      emit(c, nullptr, ptr + c.token, N, lo, hi, out);
      std::copy_n(ptr + c.token, N, c.env.s.begin());
      c.token += N;
    } else if (code == 2) {
      auto k = read(c.token);
      emit(c, nullptr, ptr + c.token, k, lo, hi, out);
      c.token += k;
    } else {
      const auto &e = event(code);
      emit(c, &c.env, e.additions.data(), e.k, lo, hi, out);
      c.env = mapped(c.env, e.perm.data());
    }
    return true;
  }
  void slice(U lo, U hi, Sink &out) {
    check(lo <= hi && hi <= length, "bad slice");
    auto it =
        std::upper_bound(index.begin(), index.end(), lo,
                         [](U x, const Cursor &c) { return x < c.offset; });
    check(it != index.begin(), "index");
    Cursor c = *std::prev(it);
    while (c.offset < hi && advance(c, lo, hi, &out)) {
    }
    check(c.offset >= hi, "short slice");
  }
  std::string str(U lo, U hi) {
    Sink s(false);
    slice(lo, hi, s);
    return s.data;
  }
};
