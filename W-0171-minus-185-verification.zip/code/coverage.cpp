// Verify a Detour word with one initial START and no literals, on 14 symbols.
#include "rotation_common.hpp"

int marker_index(const State &p) {
    auto end = p.s.begin() + N;
    auto it = std::find(p.s.begin(), end, N-1);
    check(it != end, "permutation missing D");
    return int(it - p.s.begin());
}

struct Coverage {
    Record &r;
    std::array<std::vector<State>, N> templates;
    std::vector<U> full;
    std::unordered_map<U, uint16_t> partial;
    U full_classes = 0;

    explicit Coverage(Record &record)
        : r(record), full((r.fact[N-1] + 63) / 64) {
        // For every possible location of D, precompute the indices of the
        // thirteen symbols following it in each fresh default rotation class.
        for (size_t g = 0; g < r.costs.size(); g += N) {
            const Byte *p = r.templ.data() + r.costs[g];
            for (int m = 0; m < N; ++m) {
                State t;
                for (int j = 0; j < N-1; ++j) t.s[j] = p[(m+j+1)%N];
                templates[p[m]].push_back(t);
            }
        }
    }
    void mark_full(const State &base, U count) {
        if (!count) return;
        const auto &indices = templates[marker_index(base)];
        for (U q = 0; q < count; ++q) {
            U rank = rank13(mapped(base, indices[q].s.data()).s.data());
            U &word = full[rank >> 6];
            U bit = U(1) << (rank & 63);
            if (!(word & bit)) { word |= bit; ++full_classes; }
        }
    }
    void mark_partial(const State &p, unsigned rotations) {
        const int m = marker_index(p);
        Byte rest[N-1];
        for (int j = 0; j < N-1; ++j) rest[j] = p.s[(m+j+1)%N];
        U rank = rank13(rest);
        if (full[rank >> 6] & (U(1) << (rank & 63))) return;
        auto &mask = partial[rank];
        for (unsigned j = 0; j < rotations; ++j) mask |= 1u << p.s[j];
    }
    void scan(bool full_pass) {
        State base;
        size_t pos = 22;
        check(r.read(pos) == 0 && r.read(pos) == 1, "expected initial START");
        for (int i = 0; i < N; ++i) {
            auto ch = r.ptr[pos++];
            base.s[i] = ch <= '9' ? ch-'0' : ch-'A'+10;
        }
        U length = N;
        std::array<std::vector<Intermediate>, 128> common;
        std::unordered_map<U, std::vector<Intermediate>> uncommon;
        for (;;) {
            const U g = r.read(pos), code = r.read(pos);
            // Endpoints 14q through 14q+13 are rotations of one permutation.
            // A default move of weight d appends the first d symbols in
            // reverse order. Proper intermediate windows lack the old first
            // symbol, so only the designated endpoints are permutations.
            if (full_pass) mark_full(base, (g+1)/N);
            else if (g%N != N-1) {
                const auto *p = r.templ.data() + r.costs[g-g%N];
                mark_partial(mapped(base, p), unsigned(g%N+1));
            }
            length += r.costs[g];
            if (g) base = mapped(base, r.templ.data()+r.costs[g]);
            if (!code) break;
            check(code >= 3, "additional START or literal");
            const auto &e = r.event(code);
            if (!full_pass) {
                auto &steps = code < common.size() ? common[code] : uncommon[code];
                if (steps.empty()) steps = intermediate(e);
                for (const auto &step : steps)
                    mark_partial(mapped(base, step.relative.s.data()), 1);
            }
            base = mapped(base, e.perm.data());
            length += e.k;
        }
        check(length == r.length, "decoded length mismatch");
    }
};

int main(int argc, char **argv) try {
    check(argc == 2, "usage: coverage WORD.tokens");
    Record r(argv[1]);
    Coverage c(r);
    c.scan(true);
    std::cout << "Complete rotation classes in default blocks: " << c.full_classes
              << " / " << r.fact[N-1] << std::endl;
    c.scan(false);
    U covered = c.full_classes * N;
    for (const auto &item : c.partial) covered += __builtin_popcount(item.second);
    std::cout << "Additional classes with observed rotations: " << c.partial.size()
              << "\nDistinct permutations: " << covered << " / " << r.fact[N]
              << "\nMissing permutations: " << r.fact[N]-covered
              << "\nDecoded length: " << r.length << std::endl;
    check(covered == r.fact[N], "incomplete coverage");
} catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
}
