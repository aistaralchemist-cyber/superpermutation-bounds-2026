// Apply a global alphabet bijection to a single-START, literal-free Detour word.
// All subsequent instructions act on positions within the current permutation.
#include "detour14.hpp"

int main(int argc, char **argv) try {
    check(argc == 4, "usage: relabel INPUT.tokens NEW.tokens FIRST_PERMUTATION");
    Record source(argv[1]);
    std::string first = argv[3], sorted = first;
    std::sort(sorted.begin(), sorted.end());
    check(sorted == "0123456789ABCD", "invalid target first window");
    size_t pos = 22;
    check(source.read(pos) == 0 && source.read(pos) == 1, "missing initial START");
    size_t start = pos;
    pos += N;
    for (;;) {
        source.read(pos);
        auto code = source.read(pos);
        if (!code) break;
        check(code >= 3, "additional START or literal");
    }
    check(pos + 32 == source.bytes, "invalid trailer");
    int fd = open(argv[2], O_WRONLY | O_CREAT | O_EXCL, 0600);
    check(fd >= 0, "output must be a new file");
    close(fd);
    {
        std::ofstream out(argv[2], std::ios::binary);
        out.write(reinterpret_cast<const char *>(source.ptr), start);
        out.write(first.data(), N);
        size_t from = start + N;
        out.write(reinterpret_cast<const char *>(source.ptr + from), source.bytes - from);
        out.close();
        check(bool(out), "failed to write relabeled tokens");
    }
    Record changed(argv[2]);
    check(changed.length == source.length && changed.str(0, N) == first, "invalid first window or length");
    Sink hash(true);
    changed.slice(0, changed.length, hash);
    check(hash.count == changed.length, "decoded length mismatch");
    std::string sha = hash.digest();
    std::fstream out(argv[2], std::ios::in | std::ios::out | std::ios::binary);
    out.seekp(pos);
    for (size_t i = 0; i < sha.size(); i += 2)
        out.put(static_cast<char>(std::stoi(sha.substr(i, 2), nullptr, 16)));
    out.close();
    check(bool(out), "failed to write new word hash");
    std::cout << changed.length << " " << sha << " first " << first << std::endl;
} catch (const std::exception &error) {
    std::cerr << error.what() << std::endl;
    return 1;
}
