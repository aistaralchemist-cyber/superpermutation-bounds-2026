#include "detour14.hpp"
int main(int argc,char**argv){Record r(argv[1]); Sink h(true);r.slice(0,r.length,h);auto val=h.digest();check(h.count==r.length&&val==r.trailer,"SHA-256 mismatch");std::cout<<r.length<<" "<<val<<" decoded, matches trailer.\n";}
