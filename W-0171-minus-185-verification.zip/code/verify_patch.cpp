// Check the source substrings and the overlap accounting of a piece patch.
#include "detour14.hpp"
bool permutation(std::string s) {
  std::sort(s.begin(), s.end());
  return s == "0123456789ABCD";
}
struct Cut {
  U pos, d;
  std::string before, after;
};
int main(int argc, char **argv) {
  try {
    check(argc >= 3, "usage: verify_patch TOKENFILE PATCH.tsv [--hash]");
    Record r(argv[1]);
    std::ifstream f(argv[2]);
    int m;
    U declared;
    f >> m >> declared;
    check(f && m >= 0, "patch header");
    std::vector<Cut> cuts(m);
    std::vector<U> start{0}, end;
    for (auto &c : cuts) {
      f >> c.pos >> c.d >> c.before >> c.after;
      check(c.d > 0 && c.d <= N && c.pos >= start.back(), "invalid cut");
      auto w = r.str(c.pos, c.pos + c.d + N);
      check(permutation(c.before) && permutation(c.after), "invalid endpoint");
      check(w.substr(0, N) == c.before && w.substr(c.d, N) == c.after,
            "endpoint letters mismatch");
      for (int s = 1; s < c.d; s++)
        check(!permutation(w.substr(s, N)), "intervening valid permutation");
      end.push_back(c.pos + N);
      start.push_back(c.pos + c.d);
    }
    end.push_back(r.length);
    std::vector<int> order(m + 1);
    for (auto &x : order)
      f >> x;
    auto so = order;
    std::sort(so.begin(), so.end());
    for (int i = 0; i <= m; i++)
      check(so[i] == i, "not a piece permutation");
    std::vector<int> skip(m + 1, 0);
    for (int i = 1; i <= m; i++) {
      f >> skip[i];
      check(bool(f) && skip[i] >= 0 && skip[i] < N, "bad new overlap");
      auto x = order[i - 1], y = order[i];
      int k = skip[i];
      check(r.str(end[x] - k, end[x]) == r.str(start[y], start[y] + k),
            "new overlap mismatch");
    }
    U length = 0;
    for (int i = 0; i <= m; i++) {
      int x = order[i];
      check(end[x] >= start[x] + N, "piece shorter than window");
      length += end[x] - start[x] - skip[i];
    }
    check(length == declared, "wrong resulting length");
    std::cout
        << "verified " << m
        << " consecutive-window cuts and all new overlap bytes. Source length "
        << r.length << ", source trailer " << r.trailer << ", patched length "
        << length << " (saved " << r.length - length << ")" << std::endl;
    if (argc > 3 && std::string(argv[3]) == "--hash") {
      Sink s(true);
      r.slice(0, r.length, s);
      auto original = s.digest();
      check(s.count == r.length && original == r.trailer, "bad source SHA-256");
      std::cout << "source SHA-256 " << original << std::endl;
      Sink p(true);
      for (int i = 0; i <= m; i++)
        r.slice(start[order[i]] + skip[i], end[order[i]], p);
      check(p.count == length, "hash output length");
      std::cout << "patched SHA-256 " << p.digest() << std::endl;
    }
    return 0;
  } catch (const std::exception &e) {
    std::cerr << "verification failed: " << e.what() << "\n";
    return 1;
  }
}
