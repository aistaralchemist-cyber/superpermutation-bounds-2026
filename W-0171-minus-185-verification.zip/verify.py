"""Verify the deposited word or reproduce its normalized Detour archive."""
import argparse
import hashlib
import lzma
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = 'W-0171.detour'
CANDIDATE = 'W-0171-minus-185.detour'
INPUT_HASH = 'd6eee0758cd5b427207d364b292659676f68debcbae9ed88c6080644e1dda314'
ARCHIVE_HASH = '4be001ace93a7a6284adedad2898552280b1aa0e443b2eb4217d34431ab3b9cd'
SOURCE_WORD = 'a369344aa9c7e68331e1b471f51b99d20fb0e9b0954d56b0a8f002a05ca3820c'
REORDERED = '8a149b7a88b1fec65f1c36dbde9fcdff46c17ac69a2a479ed96db3a988c4b622'
PUBLISHED = '015f5408455202a7aa7667472b84c901200cf4168b849f3571c58fde3f8c0ffc'
ALPHABET = '0123456789ABCD'
LENGTH = 93904705099


def unpack(path, expected, target):
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError(f'Unexpected SHA-256 for {path.name}')
    with lzma.open(path) as src, target.open('xb') as dst:
        shutil.copyfileobj(src, dst, 1 << 20)


def run(tool, *args):
    result = subprocess.check_output([tool, *args], text=True)
    print(result, end='', flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rebuild', type=Path, metavar='NEW_ARCHIVE',
                        help='also regenerate the word from the original and patch')
    args = parser.parse_args()
    if args.rebuild and args.rebuild.exists():
        parser.error('The rebuilt archive needs a new file name')
    original = ROOT / SOURCE
    if not original.exists():
        original = ROOT.parent / SOURCE
    lines = (ROOT / 'patch.tsv').read_text().splitlines()
    n, length = map(int, lines[0].split())
    if (n, length) != (930, LENGTH):
        raise ValueError('Unexpected patch header')
    first_id = int(lines[n+1].split()[0])
    first = lines[first_id].split()[3] if first_id else ALPHABET

    with tempfile.TemporaryDirectory(prefix='w0171-185-') as tmp:
        w = Path(tmp)
        programs = ['verify_patch', 'hashdet', 'relabel', 'coverage']
        if args.rebuild:
            programs += ['build_detour', 'canonicalize']
        for name in programs:
            cmd = ['c++', '-O3', '-std=c++17', '-Wno-deprecated-declarations',
                   str(ROOT / 'code' / (name+'.cpp')), '-o', str(w / name)]
            if sys.platform != 'darwin':
                cmd.append('-lcrypto')
            subprocess.run(cmd, check=True)
        unpack(original, INPUT_HASH, w / 'source')
        unpack(ROOT / CANDIDATE, ARCHIVE_HASH, w / 'word')
        report = run(w / 'verify_patch', w / 'source', ROOT / 'patch.tsv', '--hash')
        if ('source SHA-256 '+SOURCE_WORD not in report.splitlines() or
                'patched SHA-256 '+REORDERED not in report.splitlines()):
            raise ValueError('Source or reordered word hash mismatch')
        decoded = run(w / 'hashdet', w / 'word')
        if decoded.split()[:2] != [str(LENGTH), PUBLISHED]:
            raise ValueError('Normalized word length or hash mismatch')
        with (w / 'word').open('rb') as tokens:
            if tokens.read(38)[22:] != b'\0\1'+ALPHABET.encode():
                raise ValueError('The first window is not the identity')
        inverse = run(w / 'relabel', w / 'word', w / 'inverse', first)
        if inverse.split()[:2] != [str(LENGTH), REORDERED]:
            raise ValueError('Relabeling does not recover the certified reordering')
        run(w / 'coverage', w / 'word')
        print('Submitted archive SHA-256', ARCHIVE_HASH, flush=True)
        if args.rebuild:
            run(w / 'build_detour', w / 'source', ROOT / 'patch.tsv', w / 'assembled')
            run(w / 'canonicalize', w / 'assembled', w / 'canonical')
            rebuilt = run(w / 'relabel', w / 'canonical', w / 'rebuilt', ALPHABET)
            if rebuilt.split()[:2] != [str(LENGTH), PUBLISHED]:
                raise ValueError('Rebuilt word differs from the published word')
            with (w / 'rebuilt').open('rb') as src, lzma.open(args.rebuild, 'xb', preset=9) as dst:
                shutil.copyfileobj(src, dst, 1 << 20)
            print('Rebuilt archive SHA-256', hashlib.sha256(args.rebuild.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
