import Std

/-! Weak duality for the integer-scaled directed Hamiltonian cut certificates.
The caller represents the tour by its list of directed arcs, each vertex
occurring once as a tail and once as a head. A Hamiltonian cycle exits
every nonempty proper subset; one such exit for each priced cut suffices. -/
namespace HamiltonianCutSum

def total {A : Type} (xs : List A) (f : A → Int) : Int := (xs.map f).sum

private theorem add {A : Type} (xs : List A) (f g : A → Int) :
    total xs (fun x => f x + g x) = total xs f + total xs g := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    change f x + g x + total xs _ = (f x + total xs f) + (g x + total xs g)
    omega

private theorem mono {A : Type} (xs : List A) (f g : A → Int)
    (bound : ∀ x ∈ xs, f x ≤ g x) : total xs f ≤ total xs g := by
  induction xs with
  | nil => simp [total]
  | cons x xs ih =>
    have hx := bound x List.mem_cons_self
    have ht := ih (fun a ha => bound a (List.mem_cons_of_mem _ ha))
    change f x + total xs f ≤ g x + total xs g
    omega

private theorem perm {A : Type} {xs ys : List A} (f : A → Int) (p : xs.Perm ys) :
    total xs f = total ys f := by
  induction p with
  | nil => rfl
  | cons _ _ ih => simpa [total] using ih
  | swap => simp only [total,List.map_cons,List.sum_cons]; omega
  | trans _ _ ih ij => exact ih.trans ij

private theorem interchange {A B : Type} (xs : List A) (ys : List B) (f : A → B → Int) :
    total xs (fun x => total ys (f x)) = total ys (fun y => total xs (fun x => f x y)) := by
  induction xs with
  | nil =>
    induction ys with
    | nil => rfl
    | cons y ys ih => simpa [total] using ih
  | cons x xs ih =>
    change total ys (f x) + total xs _ = total ys (fun y => f x y + total xs (fun a => f a y))
    rw [add, ih]

private theorem total_nonnegative {A : Type} (xs : List A) (f : A → Int)
    (nonnegative : ∀ x, 0 ≤ f x) : 0 ≤ total xs f := by
  induction xs with
  | nil => simp [total]
  | cons a as ih =>
    have ha := nonnegative a
    change 0 ≤ f a + total as f
    omega

private theorem member_le {A : Type} (xs : List A) (f : A → Int)
    (nonnegative : ∀ x, 0 ≤ f x) {e : A} (he : e ∈ xs) : f e ≤ total xs f := by
  induction xs with
  | nil => contradiction
  | cons x xs ih =>
    change f e ≤ f x + total xs f
    rcases List.mem_cons.mp he with eq | head
    · subst x
      have t := total_nonnegative xs f nonnegative
      omega
    · have t := ih head
      have hx := nonnegative x
      omega

variable {V C : Type}

def exitCost (inside : C → V → Bool) (price : C → Int) (c : C) (e : V × V) : Int :=
  if inside c e.1 && !(inside c e.2) then price c else 0

/-- A scaled cost function can include a dummy vertex and negative excess
costs. Membership and arc charges are the only numerical premises. -/
theorem cut_dual (vertices : List V) (edges : List (V × V)) (cuts : List C)
    (dep arr : V → Int) (price : C → Int) (inside : C → V → Bool)
    (scaledCost : V × V → Int)
    (tails : (edges.map Prod.fst).Perm vertices)
    (heads : (edges.map Prod.snd).Perm vertices)
    (nonnegative : ∀ c, 0 ≤ price c)
    (exits : ∀ c ∈ cuts, ∃ e ∈ edges, inside c e.1 = true ∧ inside c e.2 = false)
    (arc : ∀ e ∈ edges, dep e.1 + arr e.2 +
        total cuts (fun c => exitCost inside price c e) ≤ scaledCost e) :
    total vertices dep + total vertices arr + total cuts price ≤ total edges scaledCost := by
  have bound (c) (hc : c ∈ cuts) : price c ≤ total edges (exitCost inside price c) := by
    obtain ⟨e, he, hin, hout⟩ := exits c hc
    have hn (a : V × V) : 0 ≤ exitCost inside price c a := by
      unfold exitCost
      split
      · exact nonnegative c
      · decide
    simpa [exitCost, hin, hout] using member_le edges (exitCost inside price c) hn he
  have cutBound := mono cuts _ _ bound
  rw [interchange] at cutBound
  have edgeBound := mono edges _ _ arc
  rw [add, add] at edgeBound
  have tailSum : total edges (fun e => dep e.1) = total vertices dep := by
    simpa [total,List.map_map,Function.comp_def] using perm dep tails
  have headSum : total edges (fun e => arr e.2) = total vertices arr := by
    simpa [total,List.map_map,Function.comp_def] using perm arr heads
  omega

end HamiltonianCutSum
