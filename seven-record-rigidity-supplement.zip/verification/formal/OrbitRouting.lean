import Std

/-! Charging a separated pair of labels to a path of undirected positive edges.
A unit of integer demand is represented by one route. Positive capacity is a
list of edge slots, including repetitions. This lemma is independent of the
C++ finite computations on the two seven-symbol words. -/
namespace OrbitRouting

variable {V E C : Type} [DecidableEq C]

def separated (label : V → C) (u v : V) : Nat :=
  if label u = label v then 0 else 1

private theorem triangle (label : V → C) (u v w : V) :
    separated label u w ≤ separated label u v + separated label v w := by
  by_cases huv : label u = label v
  · simp [separated, huv]
  · by_cases huw : label u = label w <;> simp [separated, huv, huw]

private theorem symmetric (label : V → C) (u v : V) :
    separated label u v = separated label v u := by
  simp only [separated, eq_comm (a:=label u) (b:=label v)]

inductive Walk (ends : E → V × V) : V → V → List E → Prop
  | nil (v) : Walk ends v v []
  | cons {u v w es} (e) (edge : ends e = (u,v) ∨ ends e = (v,u))
      (rest : Walk ends v w es) : Walk ends u w (e :: es)

def slotCharge (label : V → C) (ends : E → V × V) (es : List E) : Nat :=
  (es.map (fun e => separated label (ends e).1 (ends e).2)).sum

theorem endpoint_le_slots (label : V → C) (ends : E → V × V)
    {u w es} (path : Walk ends u w es) :
    separated label u w ≤ slotCharge label ends es := by
  induction path with
  | nil => simp [separated, slotCharge]
  | @cons u v w _ e edge _ ih =>
    have h := triangle label u v w
    have sym := symmetric label v u
    rcases edge with edge | edge <;>
      simp only [slotCharge,List.map_cons,List.sum_cons,edge] at ih ⊢ <;> omega

structure Route (ends : E → V × V) where
  src : V
  dst : V
  slots : List E
  walk : Walk ends src dst slots

private theorem charge_append (label : V → C) (ends : E → V × V) (a b : List E) :
    slotCharge label ends (a ++ b) = slotCharge label ends a + slotCharge label ends b := by
  induction a with
  | nil => simp [slotCharge]
  | cons e es ih => simp [slotCharge, Nat.add_assoc] at *

private theorem charge_perm (label : V → C) (ends : E → V × V)
    {a b : List E} (perm : a.Perm b) : slotCharge label ends a = slotCharge label ends b := by
  induction perm with
  | nil => rfl
  | cons _ _ ih => simpa [slotCharge] using ih
  | swap => simp only [slotCharge,List.map_cons,List.sum_cons]; omega
  | trans _ _ ih ij => exact ih.trans ij

/-- Every unit of separated demand is covered by a separated positive slot.
Any remaining capacity occurs in unused. This holds for arbitrary labels. -/
theorem routes_cover_demand_with_residual (label : V → C) (ends : E → V × V)
    (routes : List (Route ends)) (unused capacity : List E)
    (budget : (routes.flatMap Route.slots ++ unused).Perm capacity) :
    (routes.map (fun r => separated label r.src r.dst)).sum + slotCharge label ends unused ≤
      slotCharge label ends capacity := by
  have localBound : (routes.map (fun r => separated label r.src r.dst)).sum ≤
      slotCharge label ends (routes.flatMap Route.slots) := by
    clear budget
    induction routes with
    | nil => simp [slotCharge]
    | cons r rs ih =>
      have h := endpoint_le_slots label ends r.walk
      simp only [List.map_cons,List.sum_cons,List.flatMap_cons,charge_append]
      omega
  have eq := charge_perm label ends budget
  rw [charge_append] at eq
  omega

theorem routes_cover_demand (label : V → C) (ends : E → V × V)
    (routes : List (Route ends)) (unused capacity : List E)
    (budget : (routes.flatMap Route.slots ++ unused).Perm capacity) :
    (routes.map (fun r => separated label r.src r.dst)).sum ≤ slotCharge label ends capacity := by
  have bound := routes_cover_demand_with_residual label ends routes unused capacity budget
  omega

end OrbitRouting
