import HamiltonianCutSum
import OrbitRouting

#print axioms HamiltonianCutSum.cut_dual
#print axioms OrbitRouting.routes_cover_demand
#print axioms OrbitRouting.routes_cover_demand_with_residual
