"""Reproduce both finite proofs and independently spell the two strict witnesses."""
import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
import lzma
from itertools import permutations
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
FILES = ("data/W-0021.txt", "data/teodorescu-sol2.txt")


def check(condition, message):
    if not condition:
        raise ValueError(message)


def check_words():
    alphabet = "0123456"
    patterns = {"".join(p) for p in permutations(alphabet)}
    orbit = {alphabet[i:] + alphabet[:i] for i in range(7)}
    shift = str.maketrans(alphabet, "6012345")
    for filename in FILES:
        word = (ROOT / filename).read_text().strip()
        order = list(dict.fromkeys(word[i:i + 7] for i in range(len(word) - 6)
                                   if word[i:i + 7] in patterns))
        check(len(word) == 5905 and set(order) == patterns, "reference")
        changed = [p.translate(shift) if p in orbit else p for p in order]
        check(set(changed) == patterns, "orbit relabelling")
        spelled = changed[0]
        for p in changed[1:]:
            best = next(k for k in range(6, -1, -1) if spelled.endswith(p[:k]))
            spelled += p[best:]
        check(len(spelled) == 5906 and all(p in spelled for p in patterns), "5906 witness")
        print(f"{filename}: 5906-letter witness SHA-256 {sha256(spelled.encode()).hexdigest()}")
    word = (ROOT / FILES[0]).read_text().strip()
    lengths = []
    previous = -2
    for pos in range(len(word) - 6):
        if word[pos:pos + 7] in patterns:
            if pos == previous + 1:
                lengths[-1] += 1
            else:
                lengths.append(7)
            previous = pos
    print(f"W-0021 fragment lengths and multiplicities: {sorted(Counter(lengths).items())}")


def check_fragment_summary():
    with lzma.open(ROOT / "data/one-fragment-duals.json.xz", "rt") as source:
        certificates = json.load(source)
    bounds = []
    for certificate in certificates.values():
        # One dummy vertex is appended. The real pieces partition 5,040 windows.
        count = len(certificate["arrive"]) - 1
        baseline = 7 + 2 * (count - 1) + (5040 - count)
        scale = certificate["scale"]
        check(scale == 10000, "unexpected scale")
        objective = sum(certificate["arrive"]) + sum(certificate["depart"])
        objective += sum(weight for _, weight in certificate["cuts"])
        bounds.append(baseline + Fraction(objective, scale))
    check(len(bounds) == 782 and min(bounds) == Fraction(59040219, 10000)
          and max(bounds) == 5905, "fragment price summary")
    print(f"782 certified bounds from {min(bounds)} to {max(bounds)}, all at scale 10000")


def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="also check the formal lemmas using this Lean executable")
    args = parser.parse_args()
    check_words()
    check_fragment_summary()
    sys.stdout.flush()
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        subprocess.run([sys.executable, "src/verify_open_fragment.py", FILES[0],
                        "data/one-fragment-duals.json.xz"], cwd=ROOT, check=True)
        executable = work / "check-orbits"
        subprocess.run(["c++", "-O3", "-std=c++17", "src/verify_orbit_relabelings.cpp",
                        "-o", str(executable)], cwd=ROOT, check=True)
        subprocess.run([str(executable), *FILES], cwd=ROOT, check=True)
        if args.lean:
            lean = shutil.which(args.lean)
            check(lean, "Lean executable unavailable")
            lean = str(Path(lean).resolve())
            env = {**os.environ, "LEAN_PATH": str(work)}
            print(subprocess.check_output([lean, "--version"], cwd=work, text=True).strip(), flush=True)
            for module in ("HamiltonianCutSum", "OrbitRouting"):
                src = module + ".lean"
                shutil.copy2(ROOT / "formal" / src, work / src)
                subprocess.run([lean, "-o", module + ".olean", src], cwd=work, env=env, check=True)
            shutil.copy2(ROOT / "formal" / "Audit.lean", work / "Audit.lean")
            subprocess.run([lean, "Audit.lean"], cwd=work, env=env, check=True)


if __name__ == "__main__":
    run()
