// Check a Hamiltonian cut dual for every one-fragment opening of W-0021.
// A dummy vertex closes the spelling into a cycle. Its incident arcs cost 0.
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
using std::string;
using std::vector;
using Integer = std::int64_t;
struct Bounds {
    int scale;
    vector<int> depart, arrive, group;
    vector<vector<int>> crossing;
    Integer objective;
};
static void ensure(bool condition) {
    if (!condition) throw std::runtime_error("Invalid certificate");
}
static int read_integer() {
    int n;
    if (!(std::cin >> n)) throw std::runtime_error("Truncated data");
    ensure(n >= -1000000 && n <= 1000000);
    return n;
}
static Bounds read_bounds(int nodes) {
    Bounds result;
    result.scale = read_integer();
    ensure(result.scale>0);
    result.objective=0;
    for (auto list : {&result.depart,&result.arrive}) {
        for (int i=0;i<nodes;++i) {
            int value=read_integer();
            list->push_back(value);
            result.objective+=value;
        }
    }
    int count=read_integer();
    ensure(0<=count && count<=1000);
    vector<int> prices(count);
    vector<vector<char>> masks(nodes,vector<char>(count));
    for (int k=0;k<count;++k) {
        prices[k]=read_integer();
        int size=read_integer();
        ensure(prices[k]>0 && size>0 && size<nodes);
        result.objective+=prices[k];
        for (int a=0;a<size;++a) {
            int v=read_integer();
            ensure(v>=0 && v<nodes && !masks[v][k]);
            masks[v][k]=1;
        }
    }
    std::map<vector<char>,int> unique;
    vector<vector<char>> types;
    for (const auto &mask : masks) {
        auto [pos,inserted]=unique.try_emplace(mask,types.size());
        if (inserted) types.push_back(mask);
        result.group.push_back(pos->second);
    }
    const int groups=types.size();
    result.crossing.assign(groups,vector<int>(groups));
    for(int a=0;a<groups;++a) for(int b=0;b<groups;++b)
        for(int k=0;k<count;++k) if(types[a][k] && !types[b][k])
            result.crossing[a][b]+=prices[k];
    return result;
}
static int excess(const string &tail, const string &head) {
    for(int step=1;step<=7;++step) if(tail.compare(step,7-step,head,0,7-step)==0)
        return step-2;
    throw std::runtime_error("Missing empty overlap");
}
int main() {
    int count=read_integer();
    ensure(count==786);
    vector<string> pieces(count);
    for(string &p : pieces) {std::cin>>p;ensure(p.size()>=7 && p.size()<=13);}
    std::uint64_t arcs=0;
    int certificates=0,internal=0;
    // Cache all head/tail differences once; every component begins/ends with
    // one of the 5,040 pre-existing distinct permutation windows.
    std::map<string,int> index;
    vector<string> words;
    for(const string &p : pieces) for(int k=0;k+7<=(int)p.size();++k){
        string w=p.substr(k,7);
        ensure(index.count(w)==0);
        index[w]=words.size();words.push_back(w);
    }
    ensure(words.size()==5040);
    vector<vector<std::int8_t>> cost(words.size(),vector<std::int8_t>(words.size()));
    for(size_t i=0;i<words.size();++i) for(size_t j=0;j<words.size();++j)
        cost[i][j]=static_cast<std::int8_t>(excess(words[i],words[j]));
    for(int opened=0;opened<count;++opened) {
        const string &p=pieces[opened];
        if(p.size()==7)continue;
        ensure(read_integer()==opened);
        vector<string> chunks=pieces;
        chunks[opened]=p.substr(0,7);
        for(int k=1;k+7<=(int)p.size();++k)chunks.push_back(p.substr(k,7));
        const int n=chunks.size(), nodes=n+1;
        const auto bounds=read_bounds(nodes);
        vector<int> head(n),tail(n);
        int baseline=7+2*(n-1);
        for(int i=0;i<n;++i) {
            head[i]=index.at(chunks[i].substr(0,7));
            tail[i]=index.at(chunks[i].substr(chunks[i].size()-7,7));
            baseline+=chunks[i].size()-7;
        }
        for(int i=0;i<nodes;++i) {
            const auto &row=bounds.crossing[bounds.group[i]];
            for(int j=0;j<nodes;++j) if(i!=j) {
                Integer charge=bounds.depart[i]+bounds.arrive[j]+row[bounds.group[j]];
                int edge=(i==n || j==n)?0:cost[tail[i]][head[j]];
                ensure(charge<=(Integer)bounds.scale*edge);
                ++arcs;
            }
        }
        ensure((Integer)baseline*bounds.scale+bounds.objective>5904LL*bounds.scale);
        ++certificates;
        internal+=p.size()-7;
    }
    ensure(certificates==782 && internal==4254);
    std::cout<<certificates<<" nontrivial fragments opened completely, "<<internal
             <<" internal unit links, "<<arcs<<" ordered arc inequalities, each minimum 5905.\n";
}
