"""Verify all one-fragment openings of the seven-symbol record W-0021.

Pass W-0021.txt and one-fragment-duals.json.xz. Compile the accompanying
C++ integer checker in a temporary directory with the system compiler.
"""
import argparse
import hashlib
import json
import lzma
from collections import Counter
from pathlib import Path
import subprocess
import tempfile

SHA = "ad3203800b59628a7e8c00cb19f21a9a35c4a208689bb1ca4d55e18a742c48e5"


def fragments(word):
    if hashlib.sha256(word.encode("ascii")).hexdigest() != SHA:
        raise ValueError("Unexpected W-0021 checksum")
    runs = []
    previous = -2
    occurred = set()
    for i in range(len(word)-6):
        p = word[i:i+7]
        if len(set(p)) != 7:
            continue
        if p in occurred:
            raise ValueError("Repeated permutation")
        occurred.add(p)
        if i == previous + 1:
            runs[-1] += p[-1]
        else:
            runs.append(p)
        previous = i
    if len(occurred) != 5040 or len(runs) != 786:
        raise ValueError("Invalid run partition")
    return runs


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("word", type=Path)
    ap.add_argument("prices", type=Path)
    args = ap.parse_args()
    pieces = fragments(args.word.read_text().strip())
    with lzma.open(args.prices, "rt") as f:
        certificates = json.load(f)
    expected = {str(i) for i, p in enumerate(pieces) if len(p)>7}
    if set(certificates) != expected:
        raise ValueError("Opening cases do not match this word")

    with tempfile.TemporaryDirectory(prefix="seven-open-") as tmp:
        checker = Path(tmp)/"check"
        subprocess.run(["c++", "-O3", "-std=c++17", str(Path(__file__).with_suffix(".cpp")),
                        "-o", str(checker)], check=True)
        model = Path(tmp)/"model.txt"
        with model.open("w") as out:
            print(len(pieces), *pieces, sep="\n", file=out)
            for i, piece in enumerate(pieces):
                if len(piece) == 7: continue
                c = certificates[str(i)]
                print(i, c["scale"], file=out)
                print(*c["depart"], file=out)
                print(*c["arrive"], file=out)
                print(len(c["cuts"]), file=out)
                for members,price in c["cuts"]:
                    print(price,len(members),*members,file=out)
        with model.open("r") as f:
            subprocess.run([str(checker)], stdin=f, check=True)


if __name__ == "__main__":
    main()
