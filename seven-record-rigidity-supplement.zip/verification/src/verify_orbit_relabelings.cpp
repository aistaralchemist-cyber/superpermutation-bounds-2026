// C++17. Each argument is a file containing a 5905-character reference word.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

constexpr int sizeG = 5040;
using Perm = array<int,7>;
using Group = vector<int>;
int encoded(const Perm& perm) {
    int code = 0;
    for (int symbol : perm) code = 8 * code + symbol;
    return code;
}

struct Universe {
    vector<Perm> perm;
    vector<int> index = vector<int>(1 << 21, -1);
    vector<uint16_t> product = vector<uint16_t>(sizeG * sizeG);
    vector<uint8_t> distance = vector<uint8_t>(sizeG * sizeG);
    vector<int> inverse = vector<int>(sizeG);
    int mul(int a, int b) const { return product[a*sizeG+b]; }
    int dist(int a, int b) const { return distance[a*sizeG+b]; }
    int conjugate(int a, int x) const { return mul(mul(a,x),inverse[a]); }

    Universe() {
        Perm p{0,1,2,3,4,5,6};
        do {
            index[encoded(p)] = perm.size();
            perm.push_back(p);
        } while (next_permutation(p.begin(),p.end()));
        for (int i=0; i<sizeG; ++i) for (int j=0; j<sizeG; ++j) {
            int code = 0;
            for (int s : perm[j]) code = 8 * code + perm[i][s];
            product[i*sizeG+j] = index[code];
            if (index[code]==0) inverse[i] = j;
            int gap = 1;
            while (gap < 7 && !equal(perm[i].begin()+gap,perm[i].end(),perm[j].begin()))
                ++gap;
            distance[i*sizeG+j] = gap;
        }
    }
    Group closure(const Group& generators) const {
        vector<bool> marked(sizeG);
        Group found{0};
        marked[0] = true;
        for (size_t i=0; i<found.size(); ++i) for (int g : generators) {
            int next = mul(g,found[i]);
            if (!marked[next]) {
                marked[next] = true;
                found.push_back(next);
            }
        }
        sort(found.begin(),found.end());
        return found;
    }
    Group generators(const Group& group) const {
        Group chosen, span{0};
        for (int g : group) if (!binary_search(span.begin(),span.end(),g)) {
            chosen.push_back(g);
            span = closure(chosen);
        }
        return chosen;
    }
    set<Group> allSubgroups() const {
        const int transposition = index[encoded({1,0,2,3,4,5,6})];
        const int cycle = index[encoded({1,2,3,4,5,6,0})];
        set<Group> known{{0}};
        vector<Group> reps{{0}};
        for (size_t r=0; r<reps.size(); ++r) {
            const Group group = reps[r], gens = generators(group);
            vector<bool> member(sizeG);
            for (int g : group) member[g] = true;
            Group normalizer;
            for (int a=0; a<sizeG; ++a)
                if (all_of(gens.begin(),gens.end(),[&](int g){ return member[conjugate(a,g)]; }))
                    normalizer.push_back(a);
            const auto symmetry = generators(normalizer);
            vector<bool> seen = member;
            for (int x=1; x<sizeG; ++x) if (!seen[x]) {
                // The extensions by y, h*y and n*y*n^-1 are conjugate
                // for h in the current group and n in its normalizer.
                Group orbit{x};
                seen[x] = true;
                for (size_t i=0; i<orbit.size(); ++i) {
                    auto visit = [&](int y) {
                        if (!seen[y]) { seen[y] = true; orbit.push_back(y); }
                    };
                    for (int h : gens) visit(mul(h,orbit[i]));
                    for (int n : symmetry) visit(conjugate(n,orbit[i]));
                }
                Group extended = gens;
                extended.push_back(x);
                Group child = closure(extended);
                if (!known.insert(child).second) continue;
                reps.push_back(child);
                vector<Group> conjugates{child};
                for (size_t i=0; i<conjugates.size(); ++i)
                    for (int a : {transposition,cycle}) {
                        Group image;
                        for (int h : conjugates[i]) image.push_back(conjugate(a,h));
                        sort(image.begin(),image.end());
                        if (known.insert(image).second) conjugates.push_back(std::move(image));
                    }
            }
        }
        cout << known.size() << " subgroups, " << reps.size() << " conjugacy classes\n";
        if (known.size()!=11300 || reps.size()!=96) throw runtime_error("subgroup count");
        return known;
    }
    vector<int> readOrder(const char* path) const {
        ifstream in(path);
        string word, trailing;
        if (!(in>>word) || (in>>trailing) || word.size()!=5905) throw runtime_error("word length");
        map<char,int> alphabet;
        for (char c : word) alphabet[c] = 0;
        if (alphabet.size()!=7) throw runtime_error("alphabet");
        int next = 0;
        for (auto& entry : alphabet) entry.second = next++;
        vector<int> order;
        vector<bool> found(sizeG);
        for (size_t i=0; i+7<=word.size(); ++i) {
            Perm window;
            for (int j=0; j<7; ++j) window[j] = alphabet.at(word[i+j]);
            int p = index[encoded(window)];
            if (p<0 || found[p]) continue;
            order.push_back(p);
            found[p] = true;
        }
        if (order.size()!=sizeG) throw runtime_error("coverage");
        int length = 7;
        for (int i=1; i<sizeG; ++i) length += dist(order[i-1],order[i]);
        if (length!=5905) throw runtime_error("reference spelling length");
        return order;
    }
};

struct Edge {int u,v,capacity;};

vector<int> residualComponents(int vertices, const vector<Edge>& positive, const vector<Edge>& demands) {
    vector<vector<int>> adjacent(vertices);
    vector<int> capacity;
    for (int i=0; i<int(positive.size()); ++i) {
        adjacent[positive[i].u].push_back(i);
        adjacent[positive[i].v].push_back(i);
        capacity.push_back(positive[i].capacity);
    }
    for (auto [start,end,need] : demands) while (need>0) {
        vector<int> parent(vertices,-1);
        queue<int> queue;
        queue.push(start);
        parent[start] = -2;
        while (!queue.empty() && parent[end]==-1) {
            int u = queue.front();
            queue.pop();
            for (int id : adjacent[u]) {
                const auto& e = positive[id];
                int v = e.u==u ? e.v : e.u;
                if (capacity[id]==0 || parent[v]!=-1) continue;
                parent[v] = id;
                queue.push(v);
            }
        }
        if (parent[end]==-1) throw runtime_error("unpaid demand");
        int amount = need;
        for (int v=end; v!=start;) {
            int id = parent[v];
            amount = min(amount,capacity[id]);
            const auto& e = positive[id];
            v = (v==e.u) ? e.v : e.u;
        }
        for (int v=end; v!=start;) {
            int id = parent[v];
            capacity[id] -= amount;
            const auto& e = positive[id];
            v = (v==e.u) ? e.v : e.u;
        }
        need -= amount;
    }
    vector<int> component(vertices,-1);
    int numComponents = 0;
    for (int x=0; x<vertices; ++x) if (component[x]<0) {
        vector<int> reached{x};
        component[x] = numComponents;
        for (size_t i=0; i<reached.size(); ++i) for (int id : adjacent[reached[i]]) {
            if (capacity[id]==0) continue;
            const auto& e = positive[id];
            int y = reached[i]==e.u ? e.v : e.u;
            if (component[y]<0) {
                component[y] = numComponents;
                reached.push_back(y);
            }
        }
        ++numComponents;
    }
    return component;
}

int permutedLength(const Universe& s, const vector<int>& order, const vector<int>& orbit,
                   const vector<int>& component, const vector<int>& labels) {
    int length = 7, previous = -1;
    for (int p : order) {
        int current = s.mul(labels[component[orbit[p]]],p);
        if (previous>=0) length += s.dist(previous,current);
        previous = current;
    }
    return length;
}

void verify(const Universe& s, const set<Group>& groups, const char* path) {
    const vector<int> order = s.readOrder(path);
    const int back = s.index[encoded({6,0,1,2,3,4,5})];
    const auto cyclic = s.closure({back});
    vector<int> shifted;
    for (int p : order)
        shifted.push_back(binary_search(cyclic.begin(),cyclic.end(),p) ? s.mul(back,p) : p);
    int shiftedLength = 7;
    for (int i=1; i<sizeG; ++i) shiftedLength += s.dist(shifted[i-1],shifted[i]);
    if (shiftedLength!=5906) throw runtime_error("one-orbit witness length");
    int checked = 0, immediate = 0, cases = 0;
    map<int,int> shapes;
    for (const Group& group : groups) {
        if (group.size()==1) continue;
        vector<int> orbit(sizeG,-1);
        int count = 0;
        for (int x=0; x<sizeG; ++x) if (orbit[x]<0) {
            for (int g : group) orbit[s.mul(g,x)] = count;
            ++count;
        }
        if (count * group.size()!=sizeG) throw runtime_error("orbit size");
        unordered_map<int,size_t> offset;
        vector<int> keys, costs;
        for (int i=1; i<sizeG; ++i) {
            int p = order[i-1], q = order[i], u = orbit[p], v = orbit[q];
            if (u==v) continue;
            int key = min(u,v)*count+max(u,v);
            auto [entry, fresh] = offset.try_emplace(key,costs.size());
            if (fresh) {
                keys.push_back(key);
                costs.resize(costs.size()+group.size());
            }
            int old = s.dist(p,q);
            for (size_t j=1; j<group.size(); ++j) {
                int relative = (u<v) ? group[j] : s.inverse[group[j]];
                costs[entry->second+j] += s.dist(p,s.mul(relative,q))-old;
            }
        }
        vector<Edge> positive, demands;
        for (size_t i=0; i<keys.size(); ++i) {
            auto base = costs.begin()+i*group.size();
            int fee = *min_element(base+1,base+group.size());
            int u = keys[i]/count, v = keys[i]%count;
            if (fee>0) positive.push_back({u,v,fee});
            if (fee<0) demands.push_back({u,v,-fee});
        }
        if (demands.empty()) ++immediate;
        const auto component = residualComponents(count,positive,demands);
        const int parts = 1 + *max_element(component.begin(),component.end());
        ++shapes[parts];
        if (parts>1) {
            if (parts>3 || group.size()!=6) throw runtime_error("unexpected residual graph");
            // Equality forces each connected component of unused capacity to
            // have a constant label. Uniform left multiplication lets us set
            // the first component's label to the identity, even for nonabelian H.
            int assignments = 1;
            for (int i=1; i<parts; ++i) assignments *= group.size();
            for (int choice=1; choice<assignments; ++choice) {
                vector<int> labels(parts,0);
                int value = choice;
                for (int i=1; i<parts; ++i) {
                    labels[i] = group[value % group.size()];
                    value /= group.size();
                }
                if (permutedLength(s,order,orbit,component,labels)<=5905)
                    throw runtime_error("nonuniform relabeling attains 5905 or less");
                ++cases;
            }
        }
        ++checked;
    }
    cout << path << ": " << checked << " certified, " << immediate << " directly, "
         << checked-immediate << " by routing. Restricted minimum = 5905.\n";
    for (const auto& [parts,num] : shapes)
        cout << "Residual components: " << parts << " for " << num << " subgroups.\n";
    cout << cases << " nonconstant normalized component assignments evaluated. "
         << "The minimum among nonuniform relabelings is 5906.\n";
}
int main(int argc, char** argv) {
    if (argc<2) {cerr << "Usage: verify_orbit_relabelings WORD [WORD ...]\n"; return 2;}
    Universe s;
    const auto groups = s.allSubgroups();
    for (int k=1; k<argc; ++k) verify(s,groups,argv[k]);
}
