# Rigidity of two seven-symbol superpermutation records under fragment retention and orbitwise relabelling

Jaehun Jung, Independent Researcher, Republic of Korea. 25 November 2026.

The manuscript proves two exact minima in restricted families. A seven-symbol superpermutation retaining any 785 fragments of W-0021 needs 5,905 letters. For each of two words by Andrei Teodorescu, the best nonuniform orbitwise relabelling across all subgroups needs 5,906 letters. The unrestricted optimum remains open.

## Reproduction

Extract the supplement and run the following from its top directory. The first command requires Python 3.8 or later with the standard library and a C++17 compiler named `c++`. The optional second command checks the general summation and routing arguments using Lean 4.35.0 with its standard library. Neither command downloads data or launches an optimization solver.

```sh
python3 verification/replay.py
python3 verification/replay.py --lean /absolute/path/to/lean
```

The outer Python program reconstructs each 5,906-letter witness by maximal overlaps and scans it for every permutation. The dictionary keys in `verification/data/one-fragment-duals.json.xz` are the zero-based numbers of opened fragments in W-0021 order. Each value supplies the scale, departure and arrival prices, and a list of pairs consisting of cut members and their price. At an opening, the first window replaces the opened fragment in place. Its remaining windows are appended in their original order. The dummy vertex is last.

The C++ checker in `verification/src/verify_open_fragment.cpp` checks every directed arc, including dummy arcs, and every certificate objective using integer arithmetic. The separate subgroup checker in `verification/src/verify_orbit_relabelings.cpp` constructs all subgroups, computes the transition costs and residual capacities, verifies that all negative-weight demands are routed, and evaluates the nonuniform component assignments. It verifies the strict witnesses by a second distance computation. The replay output is in `verification/replay.log`. The Lean axioms audit lists the standard axioms used by the three declarations.

## Data and attribution

Andrei Teodorescu constructed both records. The alphabet in the supplement is normalized to the digits 0 through 6. The first word appears in the [Superpermutation Almanac](https://superpermutations.com/w/W-0021). The second word comes from [Teodorescu's announcement](https://groups.google.com/g/superpermutators/c/D5sKkV2jBuc/m/MYVQA8UsAQAJ).

This study builds on Jung's [rotation-class completion criterion](https://github.com/aistaralchemist-cyber/superpermutation-completion-7/blob/4a98a9ae38cd6ec82c0ee0622a49419c3d98d453/seven-symbol-completion.pdf). Halfar reported the [unrestricted lower bound of 5,901](https://github.com/jhalfar/superpermutations/tree/8e3c02b5234b49a1422751f86f9e472706082374/proofs/n7_5901). The finite verifications in this package establish the two restricted optima independently of that lower bound.

Compile `seven-record-rigidity.tex` with Tectonic, or run pdfLaTeX twice. The supplied archive contains the source, data, and checkers for both results. The PDF is distributed alongside it.
