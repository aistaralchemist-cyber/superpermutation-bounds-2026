"""Finite checks for A completion threshold for superpermutations on any alphabet."""
from collections import deque
from fractions import Fraction
from itertools import permutations, product
from math import factorial


def canonical(p):
    i = p.index(min(p))
    return p[i:] + p[:i]


def label(ctx, n):
    if len(ctx) != n - 1 or len(set(ctx)) != n - 1:
        return None
    missing, = set(range(n)) - set(ctx)
    return canonical(ctx + (missing,))


def profile(word, n):
    m = n - 1
    visited = {label(word[i:i+m], n) for i in range(len(word)-m+1)}
    visited.discard(None)
    required = {}
    for i in range(len(word)-n+1):
        p = word[i:i+n]
        if len(set(p)) == n:
            required.setdefault(canonical(p), set()).add(p)
    completed = {q for q, rotations in required.items() if len(rotations) == n}
    return visited, completed


def rotations(p):
    return [p[j:] + p[:j] for j in range(len(p))]


def insertion_labels(ctx, n):
    return {label(rotation, n) for rotation in rotations(ctx)}


def check_seam(n):
    m = n - 1
    first = tuple(range(m))
    left = insertion_labels(first, n)
    last = first[-1:] + first[:-1]
    viable = set()
    for pair in product(range(n), repeat=2):
        t = (last + pair)[2:]
        if len(set(t)) == m and left.isdisjoint(insertion_labels(t, n)):
            viable.add(t)
    forced = first[1:-1] + first[:1] + first[-1:]
    assert viable == ({forced} if n >= 4 else set())
    ctx = first
    for step in range(1, m):
        ctx = ctx[1:-1] + ctx[:1] + ctx[-1:]
        assert (ctx == first) == (step == m - 1)


def small_visit_word(n):
    """Breadth first search on the suffix and the visited-class subset for k=0."""
    m = n-1
    classes = sorted({canonical(p) for p in permutations(range(n))})
    index = {c: 1 << i for i, c in enumerate(classes)}
    goal = (1 << len(classes)) - 1
    parent = {((), 0): None}
    todo = deque(parent)
    while todo:
        state = todo.popleft()
        suffix, mask = state
        if mask == goal:
            letters = []
            while parent[state] is not None:
                state, symbol = parent[state]
                letters.append(symbol)
            return tuple(reversed(letters))
        for a in range(n):
            buf = suffix + (a,)
            nxt = (buf[-(m-1):], mask | index.get(label(buf, n), 0))
            if nxt not in parent:
                parent[nxt] = (state, a)
                todo.append(nxt)
    raise RuntimeError("could not reach every class")


def extend_one(word, n):
    m = n-1
    visited, done = profile(word, n)
    for i in range(len(word)-m+1):
        ctx = word[i:i+m]
        q = label(ctx, n)
        if q is None or q in done:
            continue
        a, = set(range(n)) - set(ctx)
        return word[:i+m] + (a,) + ctx + word[i+m:]
    raise ValueError("word has no visited incomplete class")


def small_checks():
    minima = [None] * 3
    for length in range(2, 10):
        for word in product(range(3), repeat=length):
            visited, done = profile(word, 3)
            if len(visited) == 2:
                for k in range(len(done) + 1):
                    if minima[k] is None:
                        minima[k] = length
    assert minima == [3, 6, 9]
    print("n=3 exhaustive minima:", *minima)
    for n in (3, 4):
        N = factorial(n-1)
        word = small_visit_word(n)
        first_length = len(word)
        lower_lengths = {3: 9, 4: 33}
        assert first_length == lower_lengths[n] - n*N
        lengths = []
        for k in range(N+1):
            visited, done = profile(word, n)
            assert len(visited) == N and len(done) == k
            assert len(word) == first_length + n*k
            lengths.append(len(word))
            if k < N:
                word = extend_one(word, n)
        print(f"n={n} BFS minimum visiting length and insertion-witness lengths:", *lengths)


def threshold(n, T):
    m = n-1
    N = factorial(m)
    H = n*m-1
    Q = H-m
    assert Fraction(m, n) - Fraction(Q, H) == Fraction(1, n*H)
    R = T-factorial(n)-m
    K = min(N, R//m, (Q*R+Q-1 - H*(N-1))//(m-1))
    return K, T - n*(N-K)


def main():
    for n in range(3, 21):
        check_seam(n)
    print("Canonical full-run seams and their forced periods: n=3 through 20 passed.")
    small_checks()
    rows = [(3, 9, 0, 3), (4, 33, 0, 9), (5, 153, 4, 53), (6, 872, 25, 302),
            (7, 5900, 89, 1483), (7, 5904, 117, 1683), (7, 5905, 124, 1733),
            (14, 93904707284, 245594623, 10164740806),
            (14, 93904707285, 245594637, 10164741003)]
    for n, T, K, length in rows:
        assert threshold(n, T) == (K, length)
        print(f"n={n}   T={T:,}   K={K:,}   partial length={length:,}")


if __name__ == "__main__":
    main()
