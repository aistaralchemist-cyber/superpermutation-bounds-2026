# A rotation-class completion threshold for superpermutations on any alphabet

Jaehun Jung, Independent Researcher, Republic of Korea. Preprint, 25 November 2026.

The paper gives an explicit partial completion threshold for all alphabet sizes at least three. Theorem 1 relates the existence of a full word of target length to a partial word that visits all cyclic permutation classes and completes a prescribed number. The proof is combinatorial. The finite checks reproduce examples and calculations. Details of authorship and AI assistance appear in the manuscript.

- [English manuscript](general-rotation-completion.pdf)
- [LaTeX source](general-rotation-completion.tex)
- [Standalone verification program](verify.py)
- [Expected program output](verification.log)

## Reproduce the finite checks

Run the following with Python 3.9 or later in this directory. Only the Python standard library is required.

```sh
python3 verify.py > verification-reproduced.log
diff -u verification.log verification-reproduced.log
```

The script tests every two-letter continuation after a full run, up to relabeling, for alphabet sizes 3 through 20. It exhaustively enumerates the three-symbol profile. For three and four symbols it uses breadth-first search to obtain a shortest word visiting all rotation classes, then explicitly inserts missing rotation cycles and checks each witness by scanning the resulting word. The script also evaluates the nine rows of Table 1 using exact integer arithmetic.

At four symbols, optimality of the intermediate witness lengths follows in the paper from the known optimum of 33 for the full word and inequality (1). The search in the supplement computes the visiting minimum and the witnesses at intermediate completion levels.

## Compile the manuscript

```sh
tectonic general-rotation-completion.tex
```

The source is self-contained and also supports a standard LaTeX installation with linked references resolved by a second run. The [seven-symbol paper and Lean supplement](https://github.com/aistaralchemist-cyber/superpermutation-completion-7/tree/4a98a9ae38cd6ec82c0ee0622a49419c3d98d453) provide the fixed-alphabet comparison.
