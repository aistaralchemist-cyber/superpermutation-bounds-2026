"""Verify the two compressed words, the patch, and both decoded word hashes."""
import hashlib
import lzma
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = "W-0165.detour"
TARGET = "W-0165-minus-627.detour"
DIGEST = "e7d43a592f841e057fa10aa005c87caea7026aeea91ff4313be644731a1f876b"


def executable(name, directory):
    dest = directory / name
    command = ["c++", "-std=c++17", "-O3", "-Wno-deprecated-declarations", str(ROOT / (name + ".cpp")), "-o", str(dest)]
    if sys.platform != "darwin":
        command.append("-lcrypto")
    subprocess.run(command, check=True)
    return dest


def unpack(name, directory):
    target = directory / (name + ".tokens")
    with lzma.open(ROOT / name) as reader, target.open("wb") as out:
        shutil.copyfileobj(reader, out, length=1 << 20)
    return target


def main():
    for line in (ROOT / "artifact-sha256.log").read_text().splitlines():
        expected, name = line.split()
        with (ROOT / name).open("rb") as handle:
            digest = hashlib.sha256()
            for block in iter(lambda: handle.read(1 << 20), b""):
                digest.update(block)
            actual = digest.hexdigest()
        if actual != expected:
            raise ValueError(f"Wrong SHA-256 for {name}")
    with tempfile.TemporaryDirectory(prefix="rotation-cuts-") as tmp:
        directory = Path(tmp)
        checker = executable("verify_patch", directory)
        decoder = executable("hashdet", directory)
        source = unpack(SOURCE, directory)
        target = unpack(TARGET, directory)
        checked = subprocess.check_output([checker, source, ROOT / "patch627.tsv", "--hash"], text=True)
        print(checked, end="", flush=True)
        if "patched SHA-256 " + DIGEST not in checked:
            raise ValueError("Patch produced a different decoded word")
        actual = subprocess.check_output([decoder, target], text=True)
        print(actual, end="", flush=True)
        if not actual.startswith("93904707285 " + DIGEST + " "):
            raise ValueError("Compressed construction differs from the reconstructed word")


if __name__ == "__main__":
    main()
