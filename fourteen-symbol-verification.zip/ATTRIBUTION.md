# Attribution

The fourteen-symbol source word **W-0165** was constructed by **Jakub Halfar** and published by the Superpermutation Almanac. It shortened Jay Pantone's W-0154. The source and the reordered word are distributed under **Creative Commons Attribution 4.0 International**. This adaptation reorders 552 pieces and changes their joining overlaps. Both source and target are supplied so the saving can be verified. [Source word](https://superpermutations.com/w/W-0165) · [Prior word](https://superpermutations.com/w/W-0154) · [License](https://creativecommons.org/licenses/by/4.0/)

The earlier certified lower bound of 93,891,141,157 was proved in a separate project by Jaehun Jung. The accompanying manuscript reports that existing lower bound to give the width of the new interval. [Almanac bound 52](https://superpermutations.com/b/52)

Jaehun Jung directed this independent research. OpenAI Codex implemented and ran the construction search, verification programs and Lean proof, and drafted the manuscript. The Detour representation follows the format specified by the Superpermutation Almanac. [Format specification](https://superpermutations.com/docs/format)
