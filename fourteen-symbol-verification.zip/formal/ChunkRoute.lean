import Reorder
namespace Superpermutation.Reorder
structure Descriptor (n : Nat) where
  first : Word n
  last : Word n

inductive Route (ι : Type) where
  | one (i : ι)
  | link (i : ι) (overlap : Nat) (rest : Route ι)

namespace Route
variable {ι : Type} {n : Nat}
def head : Route ι → ι
  | .one i | .link i _ _ => i
def ids : Route ι → List ι
  | .one i => [i]
  | .link i _ r => i :: r.ids
def totalOverlap : Route ι → Nat
  | .one _ => 0
  | .link _ k r => k + r.totalOverlap
def assemble (pieces : ι → Word n) : Route ι → Word n
  | .one i => pieces i
  | .link i k r => glue (pieces i) (r.assemble pieces) k

/-- The external data must establish which endpoints actually occur on
each chunk. The chunks themselves can be arbitrarily long. -/
def Matches (d : ι → Descriptor n) (pieces : ι → Word n) : Prop :=
  ∀ i, (d i).first.length = n ∧ (d i).last.length = n ∧
    (d i).first <+: pieces i ∧ (d i).last <:+ pieces i

def fits (d : ι → Descriptor n) (i j : ι) (k : Nat) :=
  decide (k ≤ n) && ((d i).last.drop (n-k) == (d j).first.take k)

def valid (d : ι → Descriptor n) : Route ι → Bool
  | .one _ => true
  | .link i k r => fits d i r.head k && valid d r

def cleanJoins (d : ι → Descriptor n) : Route ι → Bool
  | .one _ => true
  | .link i k r => safeSeam n ((d i).last.take (n-k))
      ((d r.head).first.take k) ((d r.head).first.drop k) && cleanJoins d r

theorem head_prefix (pieces : ι → Word n) (r : Route ι) :
    pieces r.head <+: r.assemble pieces := by
  cases r with
  | one => exact List.prefix_refl _
  | link => exact List.prefix_append .. 

private theorem shared (d : ι → Descriptor n) (pieces : ι → Word n) (m : Matches d pieces)
    (i : ι) (r : Route ι) (k : Nat) (f : fits d i r.head k) :
    let a := (d i).last.take (n-k)
    let o := (d r.head).first.take k
    let b := (d r.head).first.drop k
    a++o = (d i).last ∧ o++b = (d r.head).first ∧ o.length=k ∧
      o <+: r.assemble pieces ∧ o <:+ pieces i := by
  obtain ⟨hk,he⟩ := Bool.and_eq_true_iff.mp f
  have hle : k≤n := of_decide_eq_true hk
  have eq : (d i).last.drop (n-k) = (d r.head).first.take k := beq_iff_eq.mp he
  refine ⟨?_,List.take_append_drop .., ?_, ?_, ?_⟩
  · rw [←eq,List.take_append_drop]
  · simp [List.length_take,(m r.head).1,Nat.min_eq_left hle]
  · exact (List.take_prefix ..).trans ((m r.head).2.2.1.trans (head_prefix pieces r))
  · rw [← eq]
    exact (List.drop_suffix ..).trans (m i).2.2.2

theorem contains (d : ι → Descriptor n) (pieces : ι → Word n) (m : Matches d pieces)
    (r : Route ι) (validRoute : r.valid d) {j : ι} (member : j ∈ r.ids) :
    pieces j <:+: r.assemble pieces := by
  induction r with
  | one i =>
    have e : j=i := by simpa [ids] using member
    subst j; exact List.infix_refl _
  | link i k r ih =>
    obtain ⟨f,v⟩ := Bool.and_eq_true_iff.mp validRoute
    rcases List.mem_cons.mp member with rfl | hj
    · exact glue_contains_left .. 
    · obtain ⟨_,_,hlen,hpre,hsuf⟩ := shared d pieces m i r k f
      have he := List.prefix_iff_eq_take.mp hpre
      rw [hlen] at he
      exact (ih v hj).trans (glue_contains_right _ _ k (he ▸ hsuf))

theorem preserves (d : ι → Descriptor n) (pieces : ι → Word n) (m : Matches d pieces)
    (r : Route ι) (v : r.valid d) (c : r.cleanJoins d)
    (target : Word n) (keep : ∀ i ∈ r.ids, Keeps (pieces i) target) :
    Keeps (r.assemble pieces) target := by
  induction r with
  | one i => exact keep i (by simp [ids])
  | link i k r ih =>
    obtain ⟨f,vr⟩ := Bool.and_eq_true_iff.mp v
    obtain ⟨cert,cr⟩ := Bool.and_eq_true_iff.mp c
    have rest := ih vr cr (fun j hj => keep j (List.mem_cons_of_mem i hj))
    let a := (d i).last.take (n-k)
    let o := (d r.head).first.take k
    let b := (d r.head).first.drop k
    obtain ⟨ha,hb,hlen,_,_⟩ := shared d pieces m i r k f
    obtain ⟨x,hx⟩ := (m i).2.2.2
    obtain ⟨y,hy⟩ := (m r.head).2.2.1.trans (head_prefix pieces r)
    have leftEq : x++(a++o) = pieces i := by rw [show a++o=(d i).last from ha,hx]
    have rightEq : (o++b)++y = r.assemble pieces := by rw [show o++b=(d r.head).first from hb,hy]
    have combined := old_glue x a o b y
      (by rw [show a++o=(d i).last from ha]; exact (m i).2.1)
      (by rw [show o++b=(d r.head).first from hb]; exact (m r.head).1)
      cert (leftEq ▸ keep i (List.mem_cons_self)) (rightEq ▸ rest)
    rwa [leftEq,rightEq,show o.length=k from hlen] at combined

private theorem length_sum (pieces : ι → Word n) (d : ι → Descriptor n) (m : Matches d pieces)
    (r : Route ι) (v : r.valid d) :
    (r.assemble pieces).length + r.totalOverlap = (r.ids.map (fun i => (pieces i).length)).sum := by
  induction r with
  | one i => simp [assemble,totalOverlap,ids]
  | link i k r ih =>
    obtain ⟨f,vr⟩ := Bool.and_eq_true_iff.mp v
    obtain ⟨_,_,hlen,hpre,_⟩ := shared d pieces m i r k f
    have le := hpre.length_le
    rw [hlen] at le
    have restSize := ih vr
    simp only [assemble,glue_length,totalOverlap,ids,List.map_cons,List.sum_cons]
    omega

private theorem perm_sum {a b : List Nat} (h : a.Perm b) : a.sum=b.sum := by
  induction h with
  | nil => rfl
  | cons _ _ ih => simp [ih]
  | swap => simp only [List.sum_cons]; omega
  | trans _ _ ih ij => exact ih.trans ij

theorem length_invariant (pieces : ι → Word n) (d : ι → Descriptor n) (m : Matches d pieces)
    (p q : Route ι) (vp : p.valid d) (vq : q.valid d) (same : p.ids.Perm q.ids) :
    (p.assemble pieces).length + p.totalOverlap =
    (q.assemble pieces).length + q.totalOverlap := by
  rw [length_sum pieces d m p vp,length_sum pieces d m q vq]
  exact perm_sum (same.map _)

/-- A complete correctness theorem for arbitrary reorderings with overlaps.
Only the descriptor table and the two routes enter the Boolean checks. -/
theorem patch_correct (pieces : ι → Word n) (d : ι → Descriptor n) (m : Matches d pieces)
    (old new : Route ι) (vo : old.valid d) (vn : new.valid d) (co : old.cleanJoins d)
    (same : old.ids.Perm new.ids) (original : IsSuper (old.assemble pieces)) :
    IsSuper (new.assemble pieces) ∧
    (new.assemble pieces).length + new.totalOverlap =
      (old.assemble pieces).length + old.totalOverlap := by
  have keep := old.preserves d pieces m vo co (new.assemble pieces)
    (fun i hi => keeps_of_infix (new.contains d pieces m vn (same.subset hi)))
  refine ⟨reordering_preserves original keep, ?_⟩
  rw [length_sum pieces d m new vn,length_sum pieces d m old vo]
  exact (perm_sum (same.map _)).symm

#print axioms patch_correct
end Route
end Superpermutation.Reorder
