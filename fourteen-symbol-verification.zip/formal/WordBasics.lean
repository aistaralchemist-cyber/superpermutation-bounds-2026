import Std
namespace Superpermutation
abbrev Word (n : Nat) := List (Fin n)
def IsSuper (w : Word n) : Prop := ∀ p : Word n, p.Perm (List.finRange n) → p <:+: w
end Superpermutation
