import WordBasics

/-! A finite endpoint test for cutting and reordering long superpermutation
chunks. At an old join of two overlapping length-n endpoint windows, every
permutation wholly inside neither chunk must be visible in the short seam. -/
namespace Superpermutation.Reorder

private theorem split_around {α : Type} (a m b p : List α)
    (len : p.length ≤ m.length + 1) (occur : p <:+: (a ++ m) ++ b) :
    (p <:+: a ++ m) ∨ (p <:+: m ++ b) := by
  obtain ⟨k,hk,matchAt⟩ := List.infix_iff_getElem?.mp occur
  simp only [List.length_append] at hk
  by_cases before : k < a.length
  · left
    apply List.infix_iff_getElem?.mpr
    refine ⟨k, by simp; omega, ?_⟩
    intro i hi
    have h := matchAt i hi
    rw [List.getElem?_append_left (by simp; omega)] at h
    exact h
  · right
    apply List.infix_iff_getElem?.mpr
    refine ⟨k-a.length, by simp; omega, ?_⟩
    intro i hi
    have h := matchAt i hi
    rw [List.append_assoc, List.getElem?_append_right (by omega)] at h
    simpa only [show i + (k-a.length) = i+k-a.length by omega] using h

/-- Every length-n permutation window in the short seam equals an endpoint.
The test inspects exactly seam.length - n + 1 possible starting offsets. -/
def safeSeam (n : Nat) (a overlap b : Word n) : Bool :=
  let seam := (a ++ overlap) ++ b
  (List.range (seam.length - n + 1)).all fun i =>
    let candidate := (seam.drop i).take n
    !(candidate.isPerm (List.finRange n)) ||
      candidate == (a ++ overlap) || candidate == (overlap ++ b)

theorem safeSeam_sound (a o b : Word n) (h : safeSeam n a o b)
    (p : Word n) (perm : p.Perm (List.finRange n)) (hit : p <:+: (a++o)++b) :
    p = a++o ∨ p = o++b := by
  obtain ⟨left,right,eq⟩ := hit
  have len : p.length = n := by simpa using perm.length_eq
  have size := congrArg List.length eq
  simp only [List.length_append] at size
  have hi : left.length < ((a++o)++b).length - n + 1 := by simp; omega
  have test := List.all_eq_true.mp h left.length (List.mem_range.mpr hi)
  have word : (((a++o)++b).drop left.length).take n = p := by
    rw [←eq, List.append_assoc]
    simp [←len]
  simp only [word] at test
  have yes := List.isPerm_iff.mpr perm
  simpa [yes] using test

/-- An old join with endpoints a++o and o++b contains no essential
crossing permutation if it passes the local finite test. -/
theorem old_join (x a o b y : Word n)
    (leftLen : (a++o).length = n) (rightLen : (o++b).length = n)
    (safe : safeSeam n a o b) (p : Word n) (perm : p.Perm (List.finRange n))
    (hit : p <:+: x ++ a ++ o ++ b ++ y) :
    (p <:+: x ++ a ++ o) ∨ (p <:+: o ++ b ++ y) := by
  have len : p.length = n := by simpa using perm.length_eq
  rcases split_around x (a++o) (b++y) p (by omega) (by simpa [List.append_assoc] using hit) with h | h
  · left; simpa [List.append_assoc] using h
  · rcases split_around a (o++b) y p (by omega) (by simpa [List.append_assoc] using h) with hh | hh
    · rcases safeSeam_sound a o b safe p perm (by simpa [List.append_assoc] using hh) with rfl | rfl
      · left; simpa [List.append_assoc] using (List.suffix_append x (a++o)).isInfix
      · right; exact (List.prefix_append _ _).isInfix
    · right; exact hh

/-- All target windows in old are preserved by new. -/
def Keeps (old new : Word n) : Prop := ∀ p : Word n, p.Perm (List.finRange n) →
  p <:+: old → p <:+: new

theorem keeps_of_infix {old new : Word n} (h : old <:+: new) : Keeps old new :=
  fun _ _ hp => hp.trans h

/-- Applying this inductively to old joins and proving each leaf chunk is
contained in the new order transfers the superpermutation property. -/
theorem keeps_join {new : Word n} (x a o b y : Word n)
    (hleft : (a++o).length = n) (hright : (o++b).length = n)
    (safe : safeSeam n a o b) (left : Keeps (x++a++o) new)
    (right : Keeps (o++b++y) new) : Keeps (x++a++o++b++y) new := by
  intro p hp hit
  exact (old_join x a o b y hleft hright safe p hp hit).elim (left p hp) (right p hp)

theorem reordering_preserves {old new : Word n} (ho : IsSuper old)
    (h : Keeps old new) : IsSuper new := fun p hp => h p hp (ho p hp)

/-- Glue two chunks by dropping the shared prefix from the second. -/
def glue (a b : Word n) (overlap : Nat) := a ++ b.drop overlap

theorem glue_contains_left (a b : Word n) (k : Nat) : a <:+: glue a b k :=
  (List.prefix_append ..).isInfix

theorem glue_contains_right (a b : Word n) (k : Nat) (overlap : b.take k <:+ a) :
    b <:+: glue a b k := by
  obtain ⟨start, heq⟩ := overlap
  unfold glue
  rw [← heq,List.append_assoc,List.take_append_drop]
  exact (List.suffix_append start b).isInfix

theorem glue_length (a b : Word n) (k : Nat) :
    (glue a b k).length = a.length + (b.length-k) := by simp [glue]

/-- Handle an old overlap by looking just at its two endpoint permutations. -/
theorem old_glue {new : Word n} (x a o b y : Word n)
    (hleft : (a++o).length=n) (hright : (o++b).length=n) (safe : safeSeam n a o b)
    (l : Keeps (x++(a++o)) new) (r : Keeps ((o++b)++y) new) :
    Keeps (glue (x++(a++o)) ((o++b)++y) o.length) new := by
  simpa [glue,List.append_assoc] using keeps_join x a o b y hleft hright safe
    (by simpa [List.append_assoc] using l) r

#print axioms keeps_join
#print axioms reordering_preserves
end Superpermutation.Reorder
