// Exact supplement to verify_coverage.cpp. Uses a completed full-run bitset
// from full_stage.cpp and checks the rotations of every other class.
#include "rotation_common.hpp"

constexpr unsigned ALL = (1u << N) - 1;
const std::string CANDIDATE = "e7d43a592f841e057fa10aa005c87caea7026aeea91ff4313be644731a1f876b";
int marker(const State &p) {
  for (int i=0; i<N; ++i) if(p.s[i]==13) return i;
  throw std::runtime_error("permutation has no marker");
}
U class_rank(const State &p, int m) {
  Byte norm[13];
  for(int j=0; j<13; ++j) norm[j]=p.s[(m+j+1)%N];
  return rank13(norm);
}
unsigned phases(const State &p, unsigned last) {
  unsigned mask=0;
  for(unsigned i=0; i<=last; ++i) mask |= 1u << p.s[i];
  return mask;
}

// In a circular class each of its 14 symbols is the first symbol of precisely
// one rotation. The OR of their bits therefore gives an exact coverage test.
using SmallMasks = std::unordered_map<U,uint16_t>;
struct Prefix {
  SmallMasks modes;
  void visit(const State &p, unsigned last, U) {
    const U rank=class_rank(p, marker(p));
    modes[rank] |= phases(p,last);
  }
};

struct Missing {
  U classes, from_full, completed=0, candidates=0;
  std::vector<U> full, prefix;
  std::vector<uint16_t> masks;
  std::vector<std::array<U,N>> offsets;
  std::vector<U> ranks;
  static constexpr size_t BLOCK=8; // rank/select blocks, each with 512 classes
  Missing(const Record &r, const char *file) : classes(r.fact[13]), from_full(0),
      full((classes+63)/64), prefix((full.size()+BLOCK-1)/BLOCK) {
    std::ifstream in(file, std::ios::binary);
    std::string id(64,' ');
    in.read(id.data(),id.size());
    check(in.good() && id==r.trailer, "wrong or unreadable complete-class checkpoint");
    in.read(reinterpret_cast<char*>(&from_full),sizeof(from_full));
    in.read(reinterpret_cast<char*>(full.data()),full.size()*sizeof(U));
    check(in.good() && in.peek()==EOF, "truncated or extended complete-class checkpoint");
    U missing=0;
    for(size_t j=0;j<full.size();++j) {
      if (j%BLOCK==0) prefix[j/BLOCK]=missing;
      const size_t count=std::min<U>(64,classes-j*64);
      check(count==64 || full[j] < (U(1)<<count),"invalid full-run bitmap tail");
      missing+=count-__builtin_popcountll(full[j]);
    }
    check(from_full+missing==classes,"incorrect full-run checkpoint count");
    masks.resize(missing);
    offsets.resize(missing);
    ranks.resize(missing);
    for(auto &a:offsets) a.fill(UINT64_MAX);
    std::cout<<"Rotation masks required for "<<missing<<" classes."<<std::endl;
  }
  size_t index(U rank) const {
    size_t word=rank>>6;
    U result=prefix[word/BLOCK];
    for(size_t j=word-word%BLOCK;j<word;++j)
      result+=__builtin_popcountll(~full[j]);
    return result+__builtin_popcountll(~full[word] & ((U(1)<<(rank&63))-1));
  }
  void visit(const State &p,unsigned last,U start) {
    const U rank=class_rank(p,marker(p));
    if(full[rank>>6] & (U(1)<<(rank&63))) return;
    ++candidates;
    const size_t id=index(rank);
    auto &slot=masks.at(id);
    if(slot==ALL) return;
    for(unsigned k=0;k<=last;++k) {
      auto &saved=offsets[id][p.s[k]];
      if(saved==UINT64_MAX) saved=start+k;
    }
    ranks[id]=rank;
    slot|=phases(p,last);
    completed+=(slot==ALL);
  }
};

// For a default step of weight d the d additions are p[d-1] ... p[0].
// After j letters for 0<j<d, p[0] is absent; no such window is valid.
// Every interval of 14 default endpoints from step 14q is one complete run.
// Only the last, truncated run can contribute a class missing from full.bits.
template<class Output>
U scan(Record &r, Output &output, bool enumerate_full, U limit) {
  std::unordered_map<U,std::vector<Intermediate>> sparse;
  std::array<std::vector<Intermediate>,128> common;
  U n=0,raw=0;
  bool started=false;
  State current;
  size_t pos=22;
  while(true) {
    U g=r.read(pos),code=r.read(pos);
    check(started || g==0,"default word has no initial window");
    if(g) {
      if(enumerate_full)
        for(U j=0;j+13<=g;j+=14)
          output.visit(mapped(current,r.templ.data()+r.costs[j]),13,raw-N+r.costs[j]);
      U rem=g%14;
      if(rem<13)
        output.visit(mapped(current,r.templ.data()+r.costs[g-rem]),rem,raw-N+r.costs[g-rem]);
      current=mapped(current,r.templ.data()+r.costs[g]);
      raw+=r.costs[g];
    }
    if(code==0) {
      check(raw==r.length && started,"decoded length mismatch or missing START");
      return raw;
    }
    if(code==1) {
      check(!started && !n && !g,"additional START or reset is not supported");
      started=true;
      for(int i=0;i<N;++i) {
        auto c=r.ptr[pos++];
        current.s[i]=c<='9'?c-'0':c-'A'+10;
      }
      output.visit(current,0,raw);
      raw+=N;
    } else {
      check(started && code!=2,"unsupported literal or detour before START");
      const auto &e=r.event(code);
      auto &moves=code<common.size()?common[code]:sparse[code];
      if(moves.empty()) moves=intermediate(e);
      U window=raw-N;
      for(auto &m:moves) {
        window+=m.gap;
        output.visit(mapped(current,m.relative.s.data()),0,window);
      }
      current=mapped(current,e.perm.data());
      raw+=e.k;
    }
    if(++n==limit || (limit && raw>=250000)) return raw;
  }
}

void audit(Record &r) {
  Prefix compressed, plain;
  auto end=scan(r,compressed,true,1024);
  std::string word=r.str(0,end);
  for(size_t i=0;i+N<=word.size();++i) {
    std::string s=word.substr(i,N);
    if(s.find('D')==std::string::npos) continue;
    std::string sorted=s;
    std::sort(sorted.begin(),sorted.end());
    if(sorted!="0123456789ABCD") continue;
    unsigned first=s[0]<='9'?s[0]-'0':s[0]-'A'+10;
    std::rotate(s.begin(),s.begin()+s.find('D'),s.end());
    U rank=0;
    for(int j=1;j<13;++j) {
      int less=0;
      for(int k=j+1;k<14;++k) less+=s[k]<s[j];
      rank=rank*(14-j)+less;
    }
    plain.modes[rank]|=1u<<first;
  }
  check(compressed.modes==plain.modes,"compressed masks disagree with raw literal windows");
  std::cout<<"Independent literal prefix: "<<end<<" letters, "<<plain.modes.size()
           <<" circular classes; every rotation mask agrees."<<std::endl;
}

// Read each saved 14-letter range back through the indexed decoder. Rank by
// inversion counting after a literal rotation of the ASCII word.
void dump_checked_witnesses(Record &r,const Missing &data,const char *file) {
  std::ofstream out(file);
  check(out.good(),"cannot create witness file");
  out<<"rotation_class_rank\tfirst_symbol\twindow_start_zero_based\tword\n";
  U got=0;
  for(size_t j=0;j<data.masks.size();++j) for(int sym=0;sym<N;++sym) {
    U at=data.offsets[j][sym];
    if(at==UINT64_MAX) continue;
    std::string s=r.str(at,at+N), sorted=s, normalized=s;
    std::sort(sorted.begin(),sorted.end());
    check(sorted=="0123456789ABCD","scattered witness is not a permutation");
    check(s.front()=="0123456789ABCD"[sym],"scattered witness has wrong phase");
    std::rotate(normalized.begin(),normalized.begin()+normalized.find('D'),normalized.end());
    U rank=0;
    for(int a=1;a<13;++a) {
      int less=0;
      for(int b=a+1;b<14;++b) less+=normalized[b]<normalized[a];
      rank=rank*(14-a)+less;
    }
    check(rank==data.ranks[j],"scattered witness belongs to a different circular class");
    check((data.full[rank>>6] & (U(1)<<(rank&63)))==0,"unnecessary class marked as scattered");
    out<<rank<<'\t'<<s.front()<<'\t'<<at<<'\t'<<s<<'\n'; ++got;
  }
  out.close();
  check(out.good(),"witness write failed");
  std::cout<<"Independently decoded and checked "<<got<<" individual scattered windows."<<std::endl;
}
int main(int argc,char **argv) {
  try {
    check(argc==4 || (argc==3 && std::string(argv[2])=="--audit-prefix"),
          "usage: scattered TOKEN_FILE FULL_BITS OUTPUT.tsv | scattered TOKEN_FILE --audit-prefix");
    Record r(argv[1]);
    check(r.trailer==CANDIDATE && r.length==93904707285ULL,
          "record differs from the supported candidate");
    SHAContext token_hash;
    Byte digest[32];
    hash_init(&token_hash);
    hash_update(&token_hash,r.ptr,r.bytes);
    hash_final(digest,&token_hash);
    check(hex(digest,32)=="b3bd4663b620426ad27fa1d424ea617363e20fc4b58bbe6dea7fd007b876b81b",
          "input token SHA-256 mismatch");
    audit(r);
    if(std::string(argv[2])=="--audit-prefix") return 0;
    Missing data(r,argv[2]);
    scan(r,data,false,0);
    dump_checked_witnesses(r,data,argv[3]);
    U absent=0;
    for(auto mask:data.masks) absent+=N-__builtin_popcount(mask);
    std::cout<<"Full-run classes "<<data.from_full<<", scattered classes completed "
      <<data.completed<<"/"<<data.masks.size()<<", missing permutations "<<absent
      <<", covered "<<r.fact[14]-absent<<"/"<<r.fact[14]
      <<"; length "<<r.length<<", SHA-256 "<<r.trailer<<std::endl;
    return absent!=0;
  } catch(const std::exception &e) {
    std::cerr<<e.what()<<std::endl;
    return 1;
  }
}
