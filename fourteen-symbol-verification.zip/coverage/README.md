# Direct permutation coverage of the 14-symbol construction

The decoded word has 93,904,707,285 letters and SHA-256 `e7d43a592f841e057fa10aa005c87caea7026aeea91ff4313be644731a1f876b`. The check finds all 87,178,291,200 permutations as contiguous 14-letter windows.

```sh
python3 verify.py /path/to/W-0165-minus-627.detour
```

This command needs Python 3 with lzma, a C++17 compiler, and about 1.2 GiB of temporary disk space. Linux also needs OpenSSL development headers and its crypto library. The verifier accepts this candidate's initial START and subsequent detour steps. It checks the compressed and decompressed token-file hashes. The companion construction's independent decoder verifies the decoded word hash.

1. The first pass ranks each rotation class by placing D first and taking the Lehmer rank of the remaining 13 letters. It records the 6,227,020,789 classes having 14 successive valid windows that rotate by one position. The first eight tokens are cross-checked against literal windows.
2. The second pass checks each of the other 11 classes. A default weight-`d` transition appends the first `d` symbols in reverse order. Every intermediate window at offsets 1 through `d−1` lacks the original first symbol. Every complete group of 14 default permutation endpoints is therefore covered in the first pass. The second pass inspects the final truncated group in every default block, the initial permutation and every valid window within each explicit detour.
3. For an outstanding class, the checker marks the first symbol of each observed rotation. All 14 possible first symbols occur for each of the 11 classes. The program rereads the 154 saved offsets using the indexed decoder and checks each literal of length 14 against its expected class and first symbol. The output agrees with [the supplied table](scattered.tsv). Offsets are zero-based. A separate literal comparison on the first 250,597 letters confirms all 16,618 rotation masks in this prefix.

The [full-run counts](full.log) and [scattered-window checks](scattered.log) report the observed counts. The full-run verifier and Detour decoder derive from this project's earlier 14-symbol checks. The source word for the reordered construction is [Jakub Halfar's W-0165](https://superpermutations.com/w/W-0165).
