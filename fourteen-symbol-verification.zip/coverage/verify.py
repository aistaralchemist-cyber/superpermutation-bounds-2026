"""Reproduce all 14! coverage checks and the 154 scattered-window witnesses."""
import argparse
import hashlib
import lzma
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

COMPRESSED_SHA256 = "9ee260f21c89441f67ca63df159a277887211c7831a945d322fdbe238424e4ea"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path, help="path to W-0165-minus-627.detour")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if hashlib.sha256(args.word.read_bytes()).hexdigest() != COMPRESSED_SHA256:
        raise ValueError("Compressed artifact SHA-256 differs from the certified word.")
    with tempfile.TemporaryDirectory(prefix="fourteen-rotations-") as temporary:
        work = Path(temporary)
        tokens, checkpoint, table = (work / n for n in ("word.tokens", "full.bits", "scattered.tsv"))
        with lzma.open(args.word, "rb") as source, tokens.open("wb") as out:
            shutil.copyfileobj(source, out, 1024 * 1024)
        for program in ("full_stage", "scattered"):
            command = ["c++", "-std=c++17", "-O3", "-Wno-deprecated-declarations",
                       str(root / (program + ".cpp")), "-o", str(work / program)]
            if sys.platform != "darwin":
                command.append("-lcrypto")
            subprocess.run(command, check=True)
        subprocess.run([work / "full_stage", tokens, checkpoint], check=True)
        subprocess.run([work / "scattered", tokens, checkpoint, table], check=True)
        if table.read_bytes() != (root / "scattered.tsv").read_bytes():
            raise ValueError("Regenerated window witnesses differ from the supplied table.")
        print("All 154 regenerated witness rows match scattered.tsv.")


if __name__ == "__main__":
    main()
