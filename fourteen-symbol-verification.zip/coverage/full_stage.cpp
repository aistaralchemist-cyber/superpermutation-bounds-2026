// A full rotation run contains all 14 shifts of one circle.  Normalize a
// circle by placing D before its remaining 13 symbols, then mark its Lehmer
// rank.  Seeing all 13! ranks suffices for all 14! ordinary permutations.
#include "rotation_common.hpp"
using Transform = std::array<Byte, 16>;
struct Classes {
  std::vector<U> bits;
  std::array<std::vector<Transform>, N> normalized;
  U full = 0, distinct = 0;
  bool audit = true;
  std::vector<U> first_marks;
  explicit Classes(const Record &r) : bits((r.fact[13] + 63) / 64) {
    // At default steps 0,14,28,... fresh rotation runs begin. Index each
    // template by the position of actual symbol D in the starting permutation.
    for (size_t g = 0; g < r.costs.size(); g += N) {
      const Byte *p = r.templ.data() + r.costs[g];
      for (int t = 0; t < N; ++t) {
        Transform perm{};
        for (int i = 0; i < 13; ++i)
          perm[i] = p[(t + 1 + i) % N];
        normalized[p[t]].push_back(perm);
      }
    }
  }
  int marker(const State &p) const {
    int pos = 0;
    while (p.s[pos] != 13)
      ++pos;
    return pos;
  }
  void mark(const State &env, const Transform &t) {
    const State normalized_word = mapped(env, t.data());
    U k = rank13(normalized_word.s.data());
    U &slot = bits[k >> 6];
    U mask = 1ULL << (k & 63);
    if (!(slot & mask)) {
      slot |= mask;
      ++distinct;
    }
    ++full;
    if (audit)
      first_marks.push_back(k);
  }
  void defaults(const State &env, U g, int &unit_steps) {
    if (!g)
      return;
    const auto &templates = normalized[marker(env)];
    if (unit_steps < 13 && unit_steps + std::min<U>(g, 13) >= 13)
      mark(env, templates[0]);
    // The first 13 steps of each following 14-step group have weight one.
    for (U j = 1; N * j + 13 <= g; ++j)
      mark(env, templates[j]);
    unit_steps = g < N ? unit_steps + int(g) : int(g % N);
  }
};

// Check the accelerated stream against raw substring scanning on an initial
// prefix. The alternate rank calculation counts inversions by direct
// comparison.
void check_prefix(Record &r, U end, const std::vector<U> &accelerated) {
  std::string raw = r.str(0, end);
  std::vector<U> slow;
  int unit_steps = 0;
  int last = -2;
  for (int i = 0; i + N <= raw.size(); ++i) {
    unsigned mask = 0;
    int marker = -1;
    for (int j = 0; j < N; ++j) {
      char ch = raw[i + j];
      int v = ch <= '9' ? ch - '0' : ch - 'A' + 10;
      mask |= 1u << v;
      if (v == 13)
        marker = j;
    }
    if (mask != (1u << N) - 1)
      continue;
    unit_steps = last + 1 == i ? unit_steps + 1 : 0;
    last = i;
    if (unit_steps != 13)
      continue;
    U rank = 0;
    for (int j = 1; j <= 12; ++j) {
      int less = 0;
      for (int k = j + 1; k <= 13; ++k)
        less += raw[i + (marker + k) % N] < raw[i + (marker + j) % N];
      rank = rank * (14 - j) + less;
    }
    slow.push_back(rank);
  }
  check(slow == accelerated, "independent raw prefix and rank check failed");
}

int main(int argc, char **argv) {
  try {
    check(argc == 3, "usage: full_stage TOKENFILE FULL_BITS");
    Record r(argv[1]);
    check(r.trailer == "e7d43a592f841e057fa10aa005c87caea7026aeea91ff4313be644731a1f876b", "unexpected candidate trailer");
    Classes sets(r);
    std::unordered_map<U, std::vector<Intermediate>> sparse;
    std::array<std::vector<Intermediate>, 128> common;
    State base;
    size_t pos = 22;
    int units = 0;
    U tokens = 0, raw_position = 0;
    for (;;) {
      U g = r.read(pos), code = r.read(pos);
      sets.defaults(base, g, units);
      raw_position += r.costs[g];
      if (g)
        base = mapped(base, r.templ.data() + r.costs[g]);
      if (!code)
        break;
      if (code == 1) {
        check(tokens == 0 && g == 0, "unsupported reset");
        for (int i = 0; i < N; ++i) {
          int ch = r.ptr[pos + i];
          base.s[i] = ch <= '9' ? ch - '0' : ch - 'A' + 10;
        }
        pos += N;
        raw_position += N;
        units = 0;
      } else if (code == 2) {
        throw std::runtime_error("unsupported literal");
      } else {
        const auto &e = r.event(code);
        auto &moves = code < common.size() ? common[code] : sparse[code];
        if (moves.empty())
          moves = intermediate(e);
        for (auto &m : moves) {
          if (m.gap != 1) {
            units = 0;
            continue;
          }
          if (++units == 13) {
            auto p = mapped(base, m.relative.s.data());
            sets.mark(p, sets.normalized[sets.marker(p)][0]);
          }
        }
        base = mapped(base, e.perm.data());
        raw_position += e.k;
      }
      if (++tokens == 8) {
        check_prefix(r, raw_position, sets.first_marks);
        sets.first_marks.clear();
        sets.audit = false;
      }
    }
    if (sets.audit)
      check_prefix(r, raw_position, sets.first_marks);
    check(raw_position == r.length, "inconsistent decoded length");
    {
      std::ofstream out(argv[2], std::ios::binary);
      check(out.good(), "cannot create full.bits");
      out.write(r.trailer.data(), r.trailer.size());
      out.write(reinterpret_cast<const char*>(&sets.distinct), sizeof(sets.distinct));
      out.write(reinterpret_cast<const char*>(sets.bits.data()), sets.bits.size()*sizeof(U));
      out.close();
      check(out.good(), "failed to write full.bits");
      std::cout << "Full contiguous classes " << sets.distinct << "/" << r.fact[13]
                << ", requiring scattered rotation check " << r.fact[13]-sets.distinct
                << ". Candidate SHA-256 " << r.trailer << std::endl;
    }
    return 0;
  } catch (const std::exception &e) {
    std::cerr << e.what() << "\n";
    return 1;
  }
}
