"""Build the canonical Detour word from the published source and the route certificate."""
import argparse
import hashlib
import lzma
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "W-0165.detour"
EXPECTED_SOURCE = "46cd175c0c38f3d0d75c1e01f6fdb9c6dc719ac05651672bbfac6e98987f3a45"
EXPECTED_TOKENS = "b3bd4663b620426ad27fa1d424ea617363e20fc4b58bbe6dea7fd007b876b81b"
EXPECTED_ARCHIVE = "9ee260f21c89441f67ca63df159a277887211c7831a945d322fdbe238424e4ea"


def tool(name, directory):
    binary = directory / name
    args = ["c++", "-O3", "-std=c++17", "-Wno-deprecated-declarations", str(ROOT / (name + ".cpp")), "-o", str(binary)]
    if sys.platform != "darwin":
        args.append("-lcrypto")
    subprocess.run(args, check=True)
    return binary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new file for the canonical XZ archive")
    output = parser.parse_args().output
    if output.exists():
        parser.error("the output path already exists")
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != EXPECTED_SOURCE:
        raise ValueError("Source word differs from the published W-0165 artifact")
    with tempfile.TemporaryDirectory(prefix="w0165-build-") as temporary:
        work = Path(temporary)
        source = work / "source.tokens"
        packed = work / "reordered.tokens"
        canonical = work / "canonical.tokens"
        archive = work / "result.detour"
        with lzma.open(SOURCE) as src, source.open("wb") as dst:
            shutil.copyfileobj(src, dst, 1 << 20)
        subprocess.run([tool("build_detour", work), source, ROOT / "patch627.tsv", packed], check=True)
        subprocess.run([tool("canonicalize", work), packed, canonical], check=True)
        digest = hashlib.sha256()
        with canonical.open("rb") as src, lzma.open(archive, "wb", preset=2) as dst:
            for block in iter(lambda: src.read(1 << 20), b""):
                digest.update(block)
                dst.write(block)
        if digest.hexdigest() != EXPECTED_TOKENS:
            raise ValueError("Canonical tokens differ from the reference")
        compressed = hashlib.sha256(archive.read_bytes()).hexdigest()
        print("Canonical token SHA-256", digest.hexdigest())
        print("Compressed SHA-256", compressed)
        if compressed != EXPECTED_ARCHIVE:
            print("This XZ implementation encodes the same tokens differently.")
        with archive.open("rb") as src, output.open("xb") as dst:
            shutil.copyfileobj(src, dst, 1 << 20)


if __name__ == "__main__":
    main()
