"""Audit the literal W-0166 intervals, pruning evidence and every DIMACS clause.

Python standard library only. No SAT-generation, matching or SAT-solver code is
imported. The sibling motif audit supplies the TSV extracted from the word.
"""

import argparse
from collections import Counter
from itertools import combinations
import json
import lzma
from pathlib import Path


DEFAULT_ROOT = Path(__file__).resolve().parents[1]
ALPHABET = frozenset("0123456789ABCD")
N = len(ALPHABET)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_interval(line):
    key, count, center, span, left, right, *runs = line.split()
    parsed = [(word, int(length)) for word, length in (run.split(":") for run in runs)]
    return (int(key), int(count), int(center), int(span), left, right, parsed)


def source_vertices(interval):
    _, _, _, span, first, last, runs = interval
    require(len(runs) == 17, "wrong number of rotation runs")
    source = ""
    for entry, length in runs:
        require(len(entry) == N and set(entry) == ALPHABET, "invalid run permutation")
        require(length > 0, "empty run")
        block = "".join(entry[i % N] for i in range(N + length - 1))
        overlap = max(k for k in range(min(N, len(source)) + 1)
                      if source.endswith(block[:k]))
        source += block[overlap:]
    require(source.startswith(first) and source.endswith(last) and first != last,
            "endpoint mismatch in spelled source")
    require(len(source) == N + span, "source length mismatch")
    sequence = []
    recovered_runs = []
    previous = -2
    for pos in range(len(source) - N + 1):
        window = source[pos:pos + N]
        if len(set(window)) == N:
            sequence.append(window)
            if pos != previous + 1:
                recovered_runs.append([window, 0])
            recovered_runs[-1][1] += 1
            previous = pos
    require([tuple(run) for run in recovered_runs] == runs,
            "literal scan found different rotation runs")
    return list(dict.fromkeys(sequence))


def integers(values, expected):
    return (isinstance(values, list) and len(values) == expected
            and all(type(value) is int for value in values))


def overlap_cost(left, right):
    # A shift d leaves N-d characters in common.  The words here are different.
    return next(d for d in range(1, N + 1) if left[d:] == right[:N-d])


def verify_matching_optimum(vertices, rows, cols, edges, dual_value):
    # A matching of entirely tight arcs attains the feasible dual value. Find
    # it in the equality graph without importing a minimum-assignment solver.
    tight = {row: [] for row in rows}
    for row, col, reduced in edges:
        if reduced == 0:
            tight[row].append(col)
    owner = {}

    def augment(row, visited):
        for col in tight[row]:
            if col in visited:
                continue
            visited.add(col)
            if col not in owner or augment(owner[col], visited):
                owner[col] = row
                return True
        return False

    for row in rows:
        require(augment(row, set()), "no perfect matching among the zero-cost arcs")
    require(set(owner) == set(cols) and set(owner.values()) == set(rows),
            "tight assignment does not use every tail and head exactly once")
    primal_cost = sum(overlap_cost(vertices[row], vertices[col]) for col, row in owner.items())
    require(primal_cost == dual_value == 250,
            "primal and dual do not certify the stated assignment minimum 250")


def verify_arcs(vertices, target_length, start, end, row_price, col_price):
    # The target length includes the initial N letters.  Distinct endpoints
    # force one outgoing edge per vertex except the end and one incoming edge
    # per vertex except the start in any occurrence order.
    rows = [v for v in range(len(vertices)) if v != end]
    cols = [v for v in range(len(vertices)) if v != start]
    require(integers(row_price, len(rows)) and integers(col_price, len(cols)),
            "invalid integer dual prices")
    tails = dict(zip(rows, row_price))
    heads = dict(zip(cols, col_price))
    dual_value = sum(tails.values()) + sum(heads.values())
    slack = target_length - N - dual_value
    require(slack >= 0, "this corpus expects a nonnegative reduced-cost budget")
    edges = []
    for i in rows:
        for j in cols:
            if i != j:
                cost = overlap_cost(vertices[i], vertices[j])
                reduced = cost - tails[i] - heads[j]
                require(reduced >= 0, "dual inequality fails on an admissible arc")
                if reduced <= slack:
                    edges.append((i, j, reduced))
    verify_matching_optimum(vertices, rows, cols, edges, dual_value)
    return slack, edges


def checked_clauses(edges, budget, n_vertices, start, end, cuts):
    outgoing = [[] for _ in range(n_vertices)]
    incoming = [[] for _ in range(n_vertices)]
    units = []
    for variable, (i, j, reduced) in enumerate(edges, 1):
        outgoing[i].append(variable)
        incoming[j].append(variable)
        units.extend([variable]*reduced)
    clauses = []
    for v in range(n_vertices):
        for required, ids in [(v != end, outgoing[v]), (v != start, incoming[v])]:
            if required:
                require(ids, "corpus has unexpected empty degree")
                clauses.append(tuple(ids))
                clauses.extend((-a, -b) for a, b in combinations(ids, 2))
            else:
                require(not ids, "an edge enters the start or leaves the end")

    # Witness for each auxiliary variable (i,k): the number of true entries
    # in units[:i] is at least k. Repetition of an arc is its integer weight.
    # The IDs are row-major in these prefix/rank coordinates.
    counter = {}
    variable_count = len(edges)
    for i, current in enumerate(units, 1):
        if budget == 0:
            clauses.append((-current,))
            continue
        for k in range(1, min(i, budget) + 1):
            variable_count += 1
            counter[i, k] = variable_count
        clauses.append((-current, counter[i, 1]))
        for k in range(1, min(i-1, budget) + 1):
            earlier = counter[i-1, k]
            clauses.append((-earlier, counter[i, k]))
            increment = (-current, -earlier)
            if k < budget:
                increment += (counter[i, k+1],)
            clauses.append(increment)

    # Both directions are necessary for any nonempty set of internal vertices:
    # the path starts and ends outside the set and visits every vertex in it.
    # This justifies each cut without trusting how it was discovered.
    for group in cuts:
        require(isinstance(group, list) and len(group) > 0, "empty or invalid cut")
        require(all(type(v) is int and 0 <= v < n_vertices for v in group),
                "invalid cut vertex")
        members = set(group)
        require(group == sorted(members) and start not in members and end not in members,
                "cut is not a sorted nonempty internal subset")
        clauses.append(tuple(var for v in group for var in outgoing[v]
                             if edges[var-1][1] not in members))
        clauses.append(tuple(var for v in group for var in incoming[v]
                             if edges[var-1][0] not in members))
    return variable_count, clauses


def compare_dimacs(path, variables, expected):
    with lzma.open(path, "rt", encoding="ascii") as source:
        lines = (line.rstrip() for line in source if line.strip() and not line.startswith("c"))
        require(next(lines).split() == ["p", "cnf", str(variables), str(len(expected))],
                "incorrect DIMACS header")
        for index, clause in enumerate(expected, 1):
            line = next(lines, None)
            require(line is not None, f"missing clause {index}")
            numbers = tuple(map(int, line.split()))
            require(numbers == (*clause, 0), f"clause {index} differs from the path encoding")
        require(next(lines, None) is None, "extra clauses after audited encoding")


def verify_case(interval, sidecar, formula):
    key, count, center, span, first, last, runs = interval
    data = json.loads(sidecar.read_text(encoding="utf-8"))
    require((int(data["key"]), data["multiplicity"], data["center"], data["step_length"],
             data["start"], data["end"]) == (key, count, center, span, first, last),
            "case disagrees with the motif extraction")
    require(data["runs"] == [[p, n] for p, n in runs], "case run sequence differs")
    words = source_vertices(interval)
    source, destination = words.index(first), words.index(last)
    budget, edges = verify_arcs(words, span + N - 1, source, destination,
                                data["row_dual"], data["column_dual"])
    variables, clauses = checked_clauses(edges, budget, len(words), source, destination,
                                         data["cuts"])
    compare_dimacs(formula, variables, clauses)
    metadata = {"vertices": len(words), "arc_variables": len(edges),
                "assignment_cost": sum(data["row_dual"]) + sum(data["column_dual"]),
                "budget": budget, "variables": variables, "clauses": len(clauses)}
    require(all(data[k] == value for k, value in metadata.items()),
            "reported statistics differ from their computed values")
    return len(words), len(edges), budget, len(data["cuts"]), variables, len(clauses)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verification", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--with-proofs", action="store_true",
                        help="also check every textual LRAT derivation by unit propagation")
    args = parser.parse_args()
    motifs = args.verification / "motifs" / "instances17.tsv"
    cases = args.verification / "sat" / "cases"
    intervals = [read_interval(line) for line in motifs.read_text().splitlines() if line.strip()]
    require(len(intervals) == 24 and len({row[0] for row in intervals}) == 24,
            "expected 24 different motif keys")
    require(sum(row[1] for row in intervals) == 17637033, "wrong total multiplicity")
    header = "case\tkey\tvertices\tarcs\tbudget\tcuts\tvariables\tclauses"
    if args.with_proofs:
        from audit_rup import verify_pair
        header += "\tRUP additions"
    print(header)
    heights = Counter()
    for i, interval in enumerate(intervals, 1):
        name = f"case-{i:02}"
        try:
            formula = cases / (name + ".cnf.xz")
            stats = verify_case(interval, cases / (name + ".json"), formula)
            if args.with_proofs:
                stats += (verify_pair(formula, cases / (name + ".lrat.xz")),)
        except ValueError as error:
            raise SystemExit(f"{name}: {error}") from error
        heights[interval[3] + N] += 1
        print(name, interval[0], *stats, sep="\t")
    require(heights == {268: 24}, "unexpected length in certified corpus")
    print("PASS: a perfect tight assignment attains the feasible dual value 250 in every case.")
    print("PASS: all 24 intervals, dual reductions, cuts and complete CNFs.")
    if args.with_proofs:
        print("PASS: derived the empty clause separately for all 24 formula/proof pairs.")


if __name__ == "__main__":
    main()
