"""Small independent checker for the positive-hint fragment of textual LRAT.

No solver, native binary or external package is needed. Run without arguments
to check each of the 24 archived proof/formula pairs, or pass one pair.
"""

import argparse
import lzma
from pathlib import Path


CASES = Path(__file__).resolve().parents[1] / "sat" / "cases"


def ensure(predicate, message):
    if not predicate:
        raise ValueError(message)


def read_formula(path):
    with lzma.open(path, "rt", encoding="ascii") as stream:
        content = (s.split() for s in stream if s.strip() and not s.startswith("c"))
        header = next(content)
        ensure(len(header) == 4 and header[:2] == ["p", "cnf"], "invalid DIMACS header")
        variables, count = map(int, header[2:])
        live = {}
        for number, tokens in enumerate(content, 1):
            row = tuple(map(int, tokens))
            ensure(row and row[-1] == 0 and all(0 < abs(v) <= variables for v in row[:-1]),
                   f"incorrect input clause {number}")
            live[number] = row[:-1]
    ensure(len(live) == count and count > 0 and variables > 0, "input size mismatch")
    return variables, live


def verify_rup_clause(clause, hints, live):
    # Assume that every literal of the new clause is false. An empty active
    # clause after forced unit assignments contradicts this assumption.
    true = {-lit for lit in clause}
    if any(lit in true for lit in clause):
        # A tautology needs no antecedents. This archive never needs a RAT step.
        return
    for i, hint in enumerate(hints):
        row = live.get(hint)
        ensure(row is not None, f"unknown or deleted antecedent {hint}")
        unit = 0
        for lit in row:
            ensure(lit not in true, f"satisfied antecedent {hint}")
            if -lit not in true:
                ensure(unit == 0 or unit == lit, f"non-unit antecedent {hint}")
                unit = lit
        if unit == 0:
            ensure(i == len(hints) - 1, "unused hints after the conflict")
            return
        true.add(unit)
    raise ValueError("ordered unit propagation ended without a conflict")


def verify_pair(formula, proof):
    variables, live = read_formula(formula)
    last = len(live)
    derived_empty = False
    additions = 0
    with lzma.open(proof, "rt", encoding="ascii") as stream:
        for line_no, line in enumerate(stream, 1):
            tokens = line.split()
            if not tokens:
                continue
            ensure(len(tokens) >= 3 and tokens[-1] == "0", f"malformed LRAT line {line_no}")
            seq = int(tokens[0])
            if tokens[1] == "d":
                ensure(seq == last, "deletion sequence number differs from current index")
                for token in tokens[2:-1]:
                    old = int(token)
                    ensure(old in live, f"cannot delete missing clause {old}")
                    del live[old]
                continue
            ensure(seq > last, f"new clause ID {seq} is not fresh")
            rest = list(map(int, tokens[1:-1]))
            split = rest.index(0)
            clause, hints = tuple(rest[:split]), rest[split+1:]
            ensure(all(0 < abs(v) <= variables for v in clause), "literal out of range")
            ensure(all(hint > 0 for hint in hints), "nonpositive hint outside RUP fragment")
            try:
                verify_rup_clause(clause, hints, live)
            except ValueError as error:
                raise ValueError(f"line {line_no}, new clause {seq}: {error}") from error
            live[seq] = clause
            last = seq
            additions += 1
            if not clause:
                derived_empty = True
    ensure(derived_empty, "no empty clause was derived")
    return additions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pair", nargs="*", type=Path, metavar="FILE")
    parser.add_argument("--cases", default=CASES, type=Path)
    args = parser.parse_args()
    if args.pair:
        if len(args.pair) != 2:
            parser.error("supply both a .cnf.xz and a .lrat.xz file")
        pairs = [tuple(args.pair)]
    else:
        pairs = [(args.cases / f"case-{i:02}.cnf.xz", args.cases / f"case-{i:02}.lrat.xz")
                 for i in range(1, 25)]
    for formula, proof in pairs:
        try:
            additions = verify_pair(formula, proof)
        except ValueError as error:
            raise SystemExit(f"{proof.name}: {error}") from error
        print(f"{proof.name}: empty clause verified after {additions:,} RUP additions.",
              flush=True)
    print(f"PASS: {len(pairs)} independently checked refutation(s).")


if __name__ == "__main__":
    main()
