# Independent audit of the 17-run intervals

From the root of the supplement run:

```sh
python3 -B verification/independent/audit_formulas.py --with-proofs
```

The audit uses the Python standard library, both scripts in this folder, the 24 rows in `verification/motifs/instances17.tsv`, and the JSON, compressed DIMACS, and compressed LRAT files in `verification/sat/cases/`. It implements its own unweighted matching check and runs independently of the producer and CaDiCaL. No network connection is needed. The motif extraction is a separate check on the inputs. For each row the output gives the motif key, vertex count, retained arcs, reduced-cost budget, cuts, Boolean variables, clauses and number of proof additions.

## From a word to an assignment

The row gives the entry permutation and number of consecutive permutation windows for each run. The auditor spells the source segment, scans its literal windows and recovers all run entries and sizes, the prescribed 14-letter endpoints and the length. The distinct permutation windows in first-occurrence order give the SAT vertex numbers. Each of the 24 segments has length 268 and requires 238 distinct permutations.

In any shorter replacement select the initial starting occurrence, the terminal ending occurrence, and one occurrence of every other required permutation. Their starting positions are distinct. Reading them in increasing order visits every vertex exactly once. If an occurrence of one 14-letter permutation starts d positions after the previous one, d is at least their minimum shift: for d below 14 the two windows already agree on their overlap, and for d at least 14 the inequality is automatic. Thus a replacement of length at most 267 gives a path with shift sum at most 253.

For the supplied integer row and column prices, the auditor recalculates every possible directed shift and tests every admissible dual inequality. Every path uses each priced tail once and each priced head once, so the price contribution is fixed. The price total is 250; every reduced shift is nonnegative and their allowed sum is at most 3. Edges with reduced shift larger than 3 cannot occur. Every path obeys the incidence equations and enters and leaves each supplied nonempty set of internal vertices. The validity of the cuts depends only on these properties of their sets.

The auditor independently computes a perfect matching of the zero-reduced-cost arcs by augmenting paths. It checks the resulting bijection and sums its literal shift costs. This sum and the feasible dual value are both 250, which certifies the minimum of the assignment relaxation.

The auditor reconstructs the row-major variable numbers and compares each DIMACS clause. The cardinality counter treats an edge of reduced shift t as t copies of its variable. On a prospective path, auxiliary variable (i,k) is true exactly when at least k copies among the first i are true. This assignment satisfies the carry, increment and overflow clauses whenever the total is at most 3. These implications suffice to rule out every shorter replacement once the CNF is refuted. The literal source segment supplies the matching upper bound.

## Checking the refutation

`audit_rup.py` reads the actual clauses of each archived DIMACS file and independently replays its textual LRAT trace. All additions in this corpus use ordered positive clause hints. For each addition the checker assumes the negation of the proposed clause, visits each hinted active clause, checks unit propagation, and requires a conflict. It removes deleted clauses and requires the derivation of the empty clause. The checker rejects RAT hints. The archived formulas and proofs coincide under the occurrence-order numbering of the 24 motifs. The command checks every pair independently.

The producer's two external LRAT checker runs are documented separately in `verification/sat/`. The Python command provides another check and verifies the mathematical interpretation of the CNF and the source of its 238 vertices.
