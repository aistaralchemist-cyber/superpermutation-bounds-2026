# Fixed-endpoint SAT certificates for the 17-run intervals

The `cases` directory has 24 descriptors, 24 DIMACS formulas and 24 textual LRAT refutations. The formulas and proofs are XZ-compressed. The cases cover 17,637,033 occurrences. Each descriptor retains its original two endpoints, runs, motif identifier and multiplicity. In the common vertex enumeration based on first appearance, all 24 inputs give identical costs, CNF bytes and proof bytes. Thus the certificates represent one shortest-path calculation on 24 separately identified, symbol-renamed instances. The identical files are included under the corresponding case names.

## Replay

Run the following from this directory with Python 3.8 or later and a C compiler. The `CC` environment variable can name a compiler executable.

~~~sh
python3 verify_proofs.py
~~~

The script builds two external open-source checkers whose unmodified C sources and license texts are in `checkers`. It accepts only their respective verified-refutation exit status and full success line. It also removes the final empty-clause derivation from the first trace and requires both checkers to reject it as a refutation. The preserved output is in [proof-replay.tsv](proof-replay.tsv). Neither checker invokes CaDiCaL. The [separate semantic auditor](../independent/audit_formulas.py) verifies that the formulas match the endpoints, local words, costs, and legitimate cuts.

| Tool | Pinned version | Role |
|---|---|---|
| [CaDiCaL](https://github.com/arminbiere/cadical/tree/rel-2.1.2) | 2.1.2 | Produce a satisfying cover for cut discovery, then an LRAT refutation of the final CNF |
| [lrat-check](https://github.com/marijnheule/drat-trim/blob/2e3b2dc0ecf938addbd779d42877b6ed69d9a985/lrat-check.c) | drat-trim commit 2e3b2dc0ecf938addbd779d42877b6ed69d9a985 | Check LRAT clause derivations against the supplied CNF |
| [lrat-trim](https://github.com/arminbiere/lrat-trim/blob/423194927df747528d5b7364806b5b77b2660c12/lrat-trim.c) | commit 423194927df747528d5b7364806b5b77b2660c12 | Check all clauses forward in RUP-only mode |

To regenerate the datasets in a fresh directory using CaDiCaL 2.1.2, run the following after reconstructing the 24 input descriptors in `../motifs/instances17.tsv`.

~~~sh
python3 generate.py ../motifs/instances17.tsv --solver /path/to/cadical --output regenerated
python3 verify_proofs.py --cases regenerated
~~~

## Connection to the local replacement problem

Each region has length 268, equivalent to 254 letters after its first 14. A shorter replacement gives a path from the specified first permutation to the specified last permutation through the 238 different required permutations. Choose their occurrences in the proposed replacement and order them by start position, using the endpoints at their fixed positions. Successive differences are at least their overlap distances. Hence such a path would cost at most 253 spelled letters after its first permutation.

In each JSON file, vertex numbers start at zero. Expand each run into its distinct rotations in occurrence order, concatenate the lists, and discard duplicate strings after their first appearance. Form row and column price vectors on the nonfinal and noninitial vertices respectively, in increasing vertex order. The sum of the integer prices is 250. Every admissible nonloop arc has cost at least the prices of its row and column combined. Any path pays each row and column price exactly once. Its remaining budget is therefore at most 3.

The CNF assigns consecutive variables to admissible arcs of reduced cost at most 3, in row-major order. For every required outdegree and indegree, an at-least-one clause and pairwise exclusion clauses impose degree one. The remaining weighted budget uses a forward unary counter with three levels. An arc is presented to the counter once for each unit of reduced cost. Every choice within budget extends to the counter variables by setting each prefix level to its actual threshold truth value.

Every recorded cut is a nonempty set containing neither endpoint. Any spanning path from start to end must both enter and leave it. For each cut, the final formula includes the clause of retained arcs leaving the set and the clause of retained arcs entering it. These clauses only need to be necessary for a path. Any hypothetical shorter word therefore supplies a model of the final CNF, independently of how the solver proposed the sets. In these calculations 15 sets of 14 vertices each supply 30 clauses. Each formula has 3,794 arc variables, 19,646 total variables and 263,040 clauses. Each proof ends in the empty clause and has 13,976 clause additions.

| Uncompressed artifact | Bytes | SHA-256 shared by the 24 cases |
|---|---:|---|
| DIMACS | 3,606,243 | ea0dce3bea2ebfb5fef14915497ede67a263e3a3c07c91add499de0941c2692b |
| LRAT | 617,732 | c65bcd17f1435717ed2ca8b2d63d51221fe6a34322c173a3301213f4635fea3d |
