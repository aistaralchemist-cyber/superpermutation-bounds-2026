"""Rebuild the 24 fixed-endpoint, strictly shorter-path instances and their LRAT proofs.

Usage: python3 generate.py ../motifs/instances17.tsv --solver /path/to/cadical --output cases
Pinned producer: CaDiCaL 2.1.2. Independently check the resulting proof with LRAT tools.
"""

import argparse
import concurrent.futures
import json
import lzma
from itertools import combinations
from pathlib import Path
import shutil
import subprocess
import tempfile


def weight(left, right):
    for overlap in range(len(left) - 1, 0, -1):
        if left[-overlap:] == right[:overlap]:
            return len(left) - overlap
    return len(left)


def rotations(word, count):
    return (word[i:] + word[:i] for i in range(min(len(word), count)))


def cardinality(literals, budget, variables, clauses):
    """Encode an at-most bound by an incremental unary count."""
    if budget == 0:
        clauses.extend([-literal] for literal in literals)
        return variables
    previous = []
    for literal in literals:
        count = min(len(previous) + 1, budget)
        current = list(range(variables + 1, variables + count + 1))
        variables += count
        clauses.append([-literal, current[0]])
        for j, old in enumerate(previous):
            clauses.append([-old, current[j]])
            if j + 1 < count:
                clauses.append([-literal, -old, current[j + 1]])
            else:
                clauses.append([-literal, -old])
        previous = current
    return variables


def matching_dual(matrix):
    """Return an exact assignment lower bound and its integer dual."""
    size = len(matrix)
    u, v, predecessor, matching = ([0] * (size + 1) for _ in range(4))
    for i in range(1, size + 1):
        matching[0] = i
        distance = [10**6] * (size + 1)
        seen = [False] * (size + 1)
        column = 0
        while True:
            seen[column] = True
            active = matching[column]
            costs = matrix[active - 1]
            shift, following = 10**6, 0
            for j, cost in enumerate(costs, 1):
                if seen[j]:
                    continue
                reduced = cost - u[active] - v[j]
                if reduced < distance[j]:
                    distance[j] = reduced
                    predecessor[j] = column
                if distance[j] < shift:
                    shift, following = distance[j], j
            for j in range(size + 1):
                if seen[j]:
                    u[matching[j]] += shift
                    v[j] -= shift
                else:
                    distance[j] -= shift
            column = following
            if matching[column] == 0:
                break
        while column:
            previous = predecessor[column]
            matching[column] = matching[previous]
            column = previous
    assert set(matching[1:]) == set(range(1, size + 1))
    primal = sum(matrix[matching[j + 1] - 1][j] for j in range(size))
    dual = sum(u[1:]) + sum(v[1:])
    assert primal == dual
    assert all(u[i + 1] + v[j + 1] <= matrix[i][j]
               for i in range(size) for j in range(size))
    return dual, u[1:], v[1:]


def compress(source, destination):
    with source.open("rb") as text, lzma.open(destination, "wb", preset=1) as compact:
        shutil.copyfileobj(text, compact)


def make_case(number, line, solver, output):
    key, occurrences, center, steps, start, end, *records = line.split()
    runs = [(sequence, int(count)) for sequence, count in (r.split(":") for r in records)]
    steps = int(steps)
    vertices = list(dict.fromkeys(w for seq, k in runs for w in rotations(seq, k)))
    source = vertices.index(start)
    target = vertices.index(end)
    assert source != target and len(runs) == 17
    rows = [i for i in range(len(vertices)) if i != target]
    cols = [j for j in range(len(vertices)) if j != source]
    matrix = [[120 if i == j else weight(vertices[i], vertices[j]) for j in cols] for i in rows]
    lower, row_dual, column_dual = matching_dual(matrix)
    budget = steps - 1 - lower
    if budget < 0:
        raise ValueError("This instance has already been excluded by the assignment lower bound")

    arcs = [None]
    incoming = [[] for _ in vertices]
    outgoing = [[] for _ in vertices]
    charges = []
    for li, i in enumerate(rows):
        for rj, j in enumerate(cols):
            if i == j:
                continue
            reduced = matrix[li][rj] - row_dual[li] - column_dual[rj]
            if reduced <= budget:
                arc = len(arcs)
                incoming[j].append(arc)
                outgoing[i].append(arc)
                charges.extend([arc] * reduced)
                arcs.append((i, j))

    clauses = []
    for i in range(len(vertices)):
        for relation, required in ((outgoing[i], i != target), (incoming[i], i != source)):
            if required:
                clauses.append(relation)
                clauses.extend([-a, -b] for a, b in combinations(relation, 2))
    variables = cardinality(charges, budget, len(arcs) - 1, clauses)
    cuts = []
    label = f"case-{number:02}"
    with tempfile.TemporaryDirectory(prefix="certified-window-") as folder:
        dimacs = Path(folder) / (label + ".cnf")
        proof = Path(folder) / (label + ".lrat")
        while True:
            with dimacs.open("w", encoding="ascii") as fp:
                fp.write(f"p cnf {variables} {len(clauses)}\n")
                for clause in clauses:
                    fp.write(" ".join(map(str, clause)) + " 0\n")
            # The first model can contain subtours. Only the last trace is kept.
            trial = subprocess.run(
                [solver, "-q", "--lrat", "--no-binary", str(dimacs), str(proof)],
                capture_output=True, text=True,
            )
            if trial.returncode == 20:
                if not proof.is_file() or not proof.stat().st_size:
                    raise ValueError("Missing LRAT proof")
                break
            if trial.returncode != 10:
                raise RuntimeError(trial.stdout + trial.stderr)
            selected = {}
            for row in trial.stdout.splitlines():
                if row.startswith("v "):
                    for literal in map(int, row.split()[1:]):
                        if 0 < literal < len(arcs):
                            left, right = arcs[literal]
                            selected[left] = right
            assert len(selected) == len(vertices) - 1
            path = {source}
            vertex = source
            while vertex != target:
                vertex = selected[vertex]
                if vertex in path:
                    raise ValueError("Invalid source-to-target model")
                path.add(vertex)
            if len(path) == len(vertices):
                raise ValueError(f"A shorter path exists for {label}")
            unseen = set(range(len(vertices))) - path
            while unseen:
                subset = set()
                vertex = min(unseen)
                while vertex not in subset:
                    subset.add(vertex)
                    vertex = selected[vertex]
                unseen.difference_update(subset)
                ordered = sorted(subset)
                assert ordered not in cuts and source not in subset and target not in subset
                cuts.append(ordered)
                clauses.append([a for i in ordered for a in outgoing[i] if arcs[a][1] not in subset])
                clauses.append([a for i in ordered for a in incoming[i] if arcs[a][0] not in subset])
        compress(dimacs, output / (label + ".cnf.xz"))
        compress(proof, output / (label + ".lrat.xz"))
    data = dict(key=int(key), multiplicity=int(occurrences), center=int(center), step_length=steps,
                start=start, end=end, runs=runs, row_dual=row_dual, column_dual=column_dual,
                cuts=cuts, vertices=len(vertices), arc_variables=len(arcs)-1, variables=variables,
                clauses=len(clauses), assignment_cost=lower, budget=budget)
    (output / (label + ".json")).write_text(json.dumps(data, separators=(",", ":")) + "\n")
    return number, key, len(vertices), len(cuts), budget, variables, len(clauses)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("instances", type=Path)
    parser.add_argument("--solver", default="cadical")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=1)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    lines = args.instances.read_text().splitlines()
    if len(lines) != 24 or len({line.split()[0] for line in lines}) != 24:
        parser.error("Expected the 24 distinct public motif types in instances17.tsv")
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.jobs) as pool:
        futures = [pool.submit(make_case, i, line, args.solver, args.output)
                   for i, line in enumerate(lines, start=1)]
        for future in futures:
            print(*future.result(), sep="\t", flush=True)


if __name__ == "__main__":
    main()
