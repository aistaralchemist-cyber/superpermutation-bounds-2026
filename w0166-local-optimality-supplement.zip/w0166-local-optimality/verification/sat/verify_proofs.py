"""Replay all 24 textual LRAT refutations with two separately compiled checkers."""
import argparse
import hashlib
import lzma
import os
from pathlib import Path
import subprocess
import tempfile


HERE = Path(__file__).resolve().parent


def run_checkers(checkers, dimacs, proof):
    results = []
    for command, success_code, required_line in checkers:
        process = subprocess.run([*command, dimacs, proof], capture_output=True, text=True)
        results.append(process.returncode == success_code and required_line in process.stdout.splitlines())
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=Path, default=HERE / "cases")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="w0166-proof-check-") as tmp:
        work = Path(tmp)
        checkers = []
        for directory, checker, options, success_code, success in [
            ("drat-trim", "lrat-check", [], 0, "c VERIFIED"),
            ("lrat-trim", "lrat-trim", ["--forward", "--no-trim", "--rup"], 20, "s VERIFIED"),
        ]:
            source = HERE / "checkers" / directory / (checker + ".c")
            binary = work / checker
            subprocess.run([os.environ.get("CC", "cc"), "-O2", str(source), "-o", str(binary)], check=True)
            checkers.append(([binary, *options], success_code, success))

        print("case\tcnf_sha256\tlrat_sha256\tlrat-check\tlrat-trim-rup")
        dimacs, proof = work/"case.cnf", work/"case.lrat"
        for i in range(1, 25):
            label = f"case-{i:02}"
            cnf_bytes = lzma.decompress((args.cases / (label+".cnf.xz")).read_bytes())
            proof_bytes = lzma.decompress((args.cases / (label+".lrat.xz")).read_bytes())
            dimacs.write_bytes(cnf_bytes)
            proof.write_bytes(proof_bytes)
            passed = run_checkers(checkers, dimacs, proof)
            if not all(passed):
                raise ValueError(f"{label} did not verify: {passed}")
            print(label, hashlib.sha256(cnf_bytes).hexdigest(), hashlib.sha256(proof_bytes).hexdigest(),
                  "VERIFIED", "VERIFIED", sep="\t", flush=True)
            if i == 1:
                # A prefix ending just before the final empty clause is not a refutation.
                lines = proof_bytes.splitlines(keepends=True)
                if lines[-1].split()[1] != b"0":
                    raise ValueError("Last proof addition must be the empty clause")
                proof.write_bytes(b"".join(lines[:-1]))
                if any(run_checkers(checkers, dimacs, proof)):
                    raise ValueError("A checker accepted the negative control")
        print("24/24 verified twice; both checkers rejected the missing-empty-clause control.")


if __name__ == "__main__":
    main()
