"""Verify every radius-four certificate without any optimizing code or solvers."""
import csv
import hashlib
import json
import sys
from pathlib import Path


def require(value, description):
    if not value:
        raise ValueError(description)


def check(shape_file, cert_file):
    certificates = json.loads(cert_file.read_text())
    tested = set()
    n = 14
    count = inequalities = 0
    with shape_file.open() as stream:
        for row in csv.DictReader(stream,delimiter="\t"):
            word = row["normalized_word"]
            digest = hashlib.sha256(word.encode("ascii")).hexdigest()
            require(digest == row["sha256"] and digest not in tested, "bad word digest")
            tested.add(digest)
            syms = set("0123456789ABCD")
            require(set(word) == syms and set(word[:n]) == syms and
                    set(word[-n:]) == syms and word[:n] != word[-n:], "bad source/target")
            required = {word[i:i+n] for i in range(len(word)-n+1) if set(word[i:i+n]) == syms}
            rows = sorted(required - {word[-n:]})
            cols = sorted(required - {word[:n]})
            cert = certificates[digest]
            u, v, matching = cert["row_dual"], cert["column_dual"], cert["row_at_column"]
            require(len(u) == len(v) == len(rows) == len(matching), "vector dimensions")
            require(all(type(z) is int for z in u+v+matching), "non-integer certificate")
            require(sorted(matching) == list(range(len(rows))), "not a perfect matching")
            primal = 0
            for j, target in enumerate(cols):
                for i, source in enumerate(rows):
                    if source == target:
                        require(matching[j] != i, "self-match")
                        continue
                    displacement = n
                    for overlap in range(n-1,0,-1):
                        if source.endswith(target[:overlap]):
                            displacement = n - overlap
                            break
                    require(u[i]+v[j] <= displacement, "infeasible dual potential")
                    inequalities += 1
                    if matching[j] == i:
                        primal += displacement
            require(primal == sum(u)+sum(v) == len(word)-n, "length bound mismatch")
            count += int(row["occurrences"])
    require(set(certificates) == tested, "missing or extra certificates")
    print(f"{len(tested)} literal shapes, {count} occurrences, {inequalities} dual inequalities checked")


if __name__ == "__main__":
    check(Path(sys.argv[1]),Path(sys.argv[2]))
