// Monoid of binary window-validity strings. Counting the runs in a
// concatenation requires just the two boundary run lengths.
#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <stdexcept>
#include <unordered_map>
#include <vector>

struct Bits {
    std::uint64_t size = 0, head = 0, tail = 0, runs15 = 0, valid = 0;
};

inline Bits append(Bits a, Bits b) {
    Bits out{a.size + b.size, a.head, b.tail, a.runs15 + b.runs15,
             a.valid + b.valid};
    if (a.size == a.head) out.head += b.head;
    if (b.size == b.tail) out.tail += a.tail;
    if (a.tail && b.head) {
        out.runs15 -= (a.tail == 15) + (b.head == 15);
        out.runs15 += (a.tail + b.head == 15);
    }
    return out;
}

class RunCounter {
    using U = std::uint64_t;
    const Bits valid{1,1,1,0,1}, invalid{1,0,0,0,0};
    std::vector<Bits> defaults = { Bits{} };
    std::unordered_map<U,Bits> explicit_move;
    // Compute the valid-window bits for an arbitrary prefix permutation.
    // The input state is identity by invariance under a permutation of symbols.
    Bits move_bits(const std::vector<int>& path) const {
        std::array<int,14> symbols;
        for (int i=0; i<14; ++i) symbols[i]=i;
        Bits result;
        for (int letter : path) {
            std::rotate(symbols.begin(), symbols.begin()+1, symbols.end());
            symbols.back() = letter;
            int mask = 0;
            for (int symbol : symbols) mask |= 1 << symbol;
            result = append(result, mask == 16383 ? valid : invalid);
        }
        return result;
    }

    Bits decode_code(U code) const {
        U rank = code-3, factorial = 1;
        int width = 1;
        while (rank >= factorial) {
            rank -= factorial;
            if (++width > 14) throw std::runtime_error("invalid move rank");
            factorial *= width;
        }
        std::vector<int> available, path;
        for (int i=width-1; i>=0; --i) available.push_back(i);
        while (!available.empty()) {
            factorial /= available.size();
            const auto index = rank / factorial;
            path.push_back(available.at(index));
            rank %= factorial;
            available.erase(available.begin()+index);
        }
        return move_bits(path);
    }
public:
    Bits stream{1,1,1,0,1}; // The one permutation window in the initial START.
    void add(U gap, U code) {
        if (gap > 10000000) throw std::runtime_error("unsupported large gap");
        while (defaults.size() <= gap) {
            U number = defaults.size();
            int width = 1;
            while (width < 14 && number % (15-width) == 0) {
                number /= 15-width;
                ++width;
            }
            std::vector<int> reversed;
            for (int j=width-1; j>=0; --j) reversed.push_back(j);
            defaults.push_back(append(defaults.back(),move_bits(reversed)));
        }
        stream = append(stream,defaults[gap]);
        if (code) {
            auto pos = explicit_move.find(code);
            if (pos == explicit_move.end())
                pos = explicit_move.emplace(code, decode_code(code)).first;
            stream = append(stream,pos->second);
        }
    }
};
