"""Generate integer assignment certificates for normalized radius-four shapes."""
import csv
import json
import sys
from pathlib import Path


def distances(word):
    n = 14
    vertices = sorted({word[i:i+n] for i in range(len(word)-n+1)
                       if len(set(word[i:i+n])) == n})
    sources = [p for p in vertices if p != word[-n:]]
    targets = [p for p in vertices if p != word[:n]]
    costs = []
    for source in sources:
        row = []
        for target in targets:
            if source == target:
                row.append(10000)
            else:
                row.append(next(i for i in range(1,n+1) if source[i:] == target[:n-i]))
        costs.append(row)
    return costs


def assignment(cost):
    """Hungarian successive augmentation with integral row and column prices."""
    n = len(cost)
    row_price = [0]*(n+1)
    col_price = [0]*(n+1)
    matched_row = [0]*(n+1)
    for row in range(1,n+1):
        matched_row[0] = row
        prev = [-1]*(n+1)
        slack = [10**9]*(n+1)
        used = [False]*(n+1)
        col = 0
        while matched_row[col]:
            used[col] = True
            r = matched_row[col]
            for c in range(1,n+1):
                if not used[c]:
                    reduced = cost[r-1][c-1] - row_price[r] - col_price[c]
                    if reduced < slack[c]:
                        prev[c], slack[c] = col, reduced
            next_col = min((c for c in range(1,n+1) if not used[c]),key=slack.__getitem__)
            delta = slack[next_col]
            for c in range(n+1):
                if used[c]:
                    row_price[matched_row[c]] += delta
                    col_price[c] -= delta
                else:
                    slack[c] -= delta
            col = next_col
        while col:
            matched_row[col] = matched_row[prev[col]]
            col = prev[col]
    return {"row_dual":row_price[1:], "column_dual":col_price[1:],
            "row_at_column":[r-1 for r in matched_row[1:]]}


if __name__ == "__main__":
    path = Path(sys.argv[1])
    with path.open() as stream:
        data = {r["sha256"]: assignment(distances(r["normalized_word"]))
                for r in csv.DictReader(stream,delimiter="\t")}
    Path(sys.argv[2]).write_text(json.dumps(data,separators=(",",":"),sort_keys=True)+"\n")
