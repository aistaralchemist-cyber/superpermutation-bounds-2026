/* Count triples in the decompressed v1 Detour stream of W-0166.
   Standard input is binary. Standard output lists key and multiplicity.
   This scanner accepts the single initial START and no literals. */
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include "run_count.hpp"

using U = std::uint64_t;

struct Reader {
    std::array<unsigned char, 1 << 16> buf;
    std::size_t offset = 0, size = 0;
    int get() {
        if (offset == size) {
            size = std::fread(buf.data(), 1, buf.size(), stdin);
            offset = 0;
            if (!size) return EOF;
        }
        return buf[offset++];
    }
    U number() {
        U value = 0;
        for (int shift = 0; shift < 63; shift += 7) {
            int c = get();
            if (c == EOF) throw std::runtime_error("truncated number");
            value |= U(c & 127) << shift;
            if (c < 128) return value;
        }
        throw std::runtime_error("bad varint");
    }
    void need(const std::string& expected) {
        for (unsigned char c : expected)
            if (get() != c) throw std::runtime_error("unexpected Detour data");
    }
};

int main() try {
    Reader input;
    input.need("Detour\x01\x0e" "0123456789ABCD");
    if (input.number() != 0 || input.number() != 1)
        throw std::runtime_error("initial START required");
    input.need("0123456789ABCD");
    RunCounter runs;
    U left = 0, middle = 0, events = 0;
    std::map<U,U> counts;
    for (;;) {
        const U gap = input.number(), code = input.number();
        if (code && code < 3) throw std::runtime_error("unexpected additional START or literal");
        runs.add(gap,code);
        if (!code) break;
        U right = 0;
        if ((code == 6 || code == 10) && gap < 65536)
            right = 2*gap + (code == 6 ? 1 : 2);
        if (left && right && middle && middle%2 == 0 && (middle/2 - 1)%14 == 13)
            ++counts[(left<<36) | (middle<<18) | right];
        left = middle;
        middle = right;
        ++events;
    }
    const unsigned char digest[] = {0xe7,0xd4,0x3a,0x59,0x2f,0x84,0x1e,0x05,0x7f,0xa1,0x0a,0xa0,0x05,0xc8,0x7c,0xae,0xa7,0x02,0x6a,0xee,0xa9,0x1f,0xf4,0x31,0x3b,0xe6,0x44,0x73,0x1a,0x1f,0x87,0x6b};
    input.need(std::string(reinterpret_cast<const char*>(digest), 32));
    if (input.get() != EOF) throw std::runtime_error("extra bytes after digest");
    if (runs.stream.size + 13 != 93904707285ULL || runs.stream.runs15 != 19861787 ||
        runs.stream.valid != 87198152990ULL) throw std::runtime_error("unexpected full-word statistics");
    std::cerr << "Length " << runs.stream.size+13 << "; valid windows " << runs.stream.valid
              << "; full-word runs of 15 windows " << runs.stream.runs15 << "\n";
    std::vector<std::pair<U,U>> ordered;
    U total = 0;
    for (auto [key, count] : counts) { ordered.emplace_back(count,key); total += count; }
    std::sort(ordered.rbegin(),ordered.rend());
    for (auto [count, key] : ordered) std::cout << key << '\t' << count << '\n';
    std::cerr << "START 1; literals 0; explicit moves " << events
              << "; keys " << ordered.size() << "; occurrences " << total << '\n';
} catch (const std::exception& e) {
    std::cerr << e.what() << '\n'; return 1;
}
