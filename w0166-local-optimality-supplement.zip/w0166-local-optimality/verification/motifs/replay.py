"""Replay occurrence counts, both lists of local words and nine matching certificates."""
import argparse
import hashlib
import lzma
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ARCHIVE_SHA = "9ee260f21c89441f67ca63df159a277887211c7831a945d322fdbe238424e4ea"
TOKEN_SHA = "b3bd4663b620426ad27fa1d424ea617363e20fc4b58bbe6dea7fd007b876b81b"


def digest(path):
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1<<20):
            sha.update(chunk)
    return sha.hexdigest()


def replay(archive, available):
    if digest(archive) != ARCHIVE_SHA:
        raise ValueError("W-0166 compressed SHA-256 mismatch")
    with tempfile.TemporaryDirectory(prefix="w0166-motifs-") as tmp:
        work = Path(tmp)
        if available:
            tokens = available
        else:
            tokens = work/"word.tokens"
            with lzma.open(archive,"rb") as source, tokens.open("wb") as out:
                shutil.copyfileobj(source,out,1<<20)
        if digest(tokens) != TOKEN_SHA:
            raise ValueError("W-0166 token stream SHA-256 mismatch")
        binary = work/"scan"
        compiler = os.environ.get("CXX","c++")
        subprocess.run([compiler,"-std=c++17","-O3",str(HERE/"count_tokens.cpp"),"-o",binary],check=True)
        histogram = work/"keys.tsv"
        with tokens.open("rb") as stream, histogram.open("wb") as output:
            subprocess.run([binary],stdin=stream,stdout=output,check=True)
        subprocess.run([sys.executable,"-B",HERE/"extract.py",histogram,work],check=True)
        for name in ("catalogue.tsv","instances17.tsv","shapes9.tsv","shapes17.tsv"):
            if (work/name).read_bytes() != (HERE/name).read_bytes():
                raise ValueError(f"{name} differs from canonical extraction")
        subprocess.run([sys.executable,"-B",HERE/"check_duals.py",work/"shapes9.tsv",HERE/"duals9.json"],check=True)
        print("All canonical-source census, exact normalized-word and matching comparisons passed.")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("archive", type=Path)
    p.add_argument("--tokens", type=Path, help="pre-uncompressed canonical stream")
    args = p.parse_args()
    replay(args.archive,args.tokens)
