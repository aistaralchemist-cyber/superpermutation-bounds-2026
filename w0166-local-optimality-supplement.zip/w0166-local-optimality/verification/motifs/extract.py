"""Reconstruct the normalized source words, both radii and their multiplicities."""
import argparse
from collections import Counter
from functools import lru_cache
import hashlib
from itertools import permutations
from pathlib import Path

ALPHABET = b"0123456789ABCD"
WIDTH = len(ALPHABET)


def tokens(key):
    result = []
    for shift in (36, 18, 0):
        tag = (key >> shift) & ((1 << 18) - 1)
        if not tag:
            raise ValueError("empty event in key")
        result.append(((tag - 1) // 2, 6 if tag % 2 else 10))
    return result


@lru_cache(None)
def expand(gap, code):
    """Emit the local normal form, starting at the alphabet in standard order."""
    word = bytearray(ALPHABET)
    for index in range(1, gap + 1):
        number, width = index, 1
        while number % (WIDTH + 1 - width) == 0:
            number //= WIDTH + 1 - width
            width += 1
        tail = word[-WIDTH:]
        word.extend(reversed(tail[:width]))
    # Codes 3, 4--5, and 6--11 have respective widths 1, 2, 3.
    # Within one width Detour orders added prefixes by descending symbols.
    order = list(permutations((2, 1, 0)))[code - 6]
    state = word[-WIDTH:]
    before_explicit = len(word)
    word.extend(state[i] for i in order)
    return bytes(word[WIDTH:]), before_explicit - WIDTH


def decode(key):
    word = bytearray(ALPHABET)
    for index, (gap, code) in enumerate(tokens(key)):
        extra, prefix_len = expand(gap, code)
        if index == 1:
            # Start of the repeated permutation ending just after the first
            # letter appended by the middle width-three detour.
            center_again = len(word) + prefix_len + 1 - WIDTH
        word.extend(extra.translate(bytes.maketrans(ALPHABET, word[-WIDTH:])))
    runs = []
    counts = [0] * 256
    distinct = 0
    for j, letter in enumerate(word):
        if j >= WIDTH:
            old = word[j-WIDTH]
            counts[old] -= 1
            distinct -= counts[old] == 0
        distinct += counts[letter] == 0
        counts[letter] += 1
        if distinct == WIDTH:
            at = j+1-WIDTH
            if runs and runs[-1][0] + runs[-1][1] == at:
                runs[-1][1] += 1
            else:
                runs.append([at,1])
    centers = [i for i,(at,count) in enumerate(runs) if count > WIDTH]
    if len(centers) != 1:
        raise ValueError("expected one repeated run per motif")
    center = centers[0]
    start, count = runs[center]
    if count != WIDTH + 1 or start + WIDTH != center_again:
        raise ValueError("middle event does not generate the designated repeat")
    return bytes(word), runs, center


def crop(word, runs, center, radius):
    select = runs[max(0, center-radius):center+radius+1]
    first, last = select[0][0], sum(select[-1]) - 1
    return word[first:last + WIDTH], [(word[at:at+WIDTH], count) for at,count in select]


def representation(key, count, center, piece, segment):
    fields = [key, count, center, len(piece)-WIDTH,
              piece[:WIDTH].decode(), piece[-WIDTH:].decode()]
    fields.extend(f"{entry.decode()}:{size}" for entry,size in segment)
    return "\t".join(map(str,fields))


def dump(rows, path):
    path.write_text("".join(row+"\n" for row in rows), encoding="ascii")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("histogram", type=Path)
    p.add_argument("output", type=Path)
    args = p.parse_args()
    counts = [tuple(map(int,line.split())) for line in args.histogram.read_text().splitlines()]
    if len(counts)!=len(dict(counts)) or counts!=sorted(counts,key=lambda kv:(kv[1],kv[0]),reverse=True):
        raise ValueError("histogram order or keys invalid")
    args.output.mkdir(exist_ok=True,parents=True)
    instances = {4:[],8:[]}
    by_width = {4:Counter(),8:Counter()}
    shape_key = {4:Counter(),8:Counter()}
    shape_occ = {4:Counter(),8:Counter()}
    normalized = {4:{},8:{}}
    first24 = set()
    internal = {4:Counter(),8:Counter()}
    first_key = {4:{},8:{}}
    catalogue = ["rank\tkey\toccurrences\truns_radius4\tshape_radius4\truns_radius8\tshape_radius8"]
    for rank,(key,occ) in enumerate(counts,1):
        word,runs,center = decode(key)
        row = [rank,key,occ]
        for radius in (4,8):
            piece, segment = crop(word,runs,center,radius)
            equivalent = piece.translate(bytes.maketrans(piece[:WIDTH], ALPHABET))
            digest = hashlib.sha256(equivalent).hexdigest()
            code = normalized[radius].setdefault(equivalent,len(normalized[radius])+1)
            row.extend([len(segment),digest])
            first_key[radius].setdefault(code,(key,len(segment)))
            if center-radius > 0 and center+radius < len(runs)-1:
                internal[radius][code] += occ
            shape_key[radius][code] += 1
            shape_occ[radius][code] += occ
            by_width[radius][(len(segment),'types')] += 1
            by_width[radius][(len(segment),'occurrences')] += occ
            if radius==4 or rank<=24:
                instances[radius].append(representation(key,occ,center,piece,segment))
            if radius==8 and rank<=24:
                first24.add(code)
        catalogue.append("\t".join(map(str,row)))
    dump(instances[4], args.output/'instances9.tsv')
    dump(instances[8], args.output/'instances17.tsv')
    dump(catalogue, args.output/'catalogue.tsv')
    for radius in (4,8):
        shape_rows = ["sha256\ttypes\toccurrences\tfirst_key\truns\tinterior_occurrences\tnormalized_word"]
        for piece,code in normalized[radius].items():
            key,run_count = first_key[radius][code]
            values = [hashlib.sha256(piece).hexdigest(),shape_key[radius][code],
                      shape_occ[radius][code],key,run_count,internal[radius][code],piece.decode()]
            shape_rows.append("\t".join(map(str,values)))
        dump(shape_rows,args.output/f"shapes{2*radius+1}.tsv")
        rows = [[width,by_width[radius][(width,'types')],value] for (width,cat),value in sorted(by_width[radius].items()) if cat=='occurrences']
        print(f"radius {radius}: [run count, token types, occurrences] = {rows}; literal normalized word shapes = {len(shape_key[radius])}")
    shared = [sum(shape_key[8][i] for i in first24),sum(shape_occ[8][i] for i in first24)]
    print(f"first 24: {sum(n for _,n in counts[:24])} occurrences, {len(first24)} literal normalized radius-eight shapes")
    print(f"all token types with these radius-eight shapes: {shared[0]}, occurrences: {shared[1]}")


if __name__ == "__main__":
    main()
