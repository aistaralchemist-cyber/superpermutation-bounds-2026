# Occurrences, normalized words and radius-four certificates

Use Python 3.8 or later and a C++17 compiler. From the verification directory run

```sh
python3 motifs/replay.py /path/to/W-0166.detour
```

The canonical archive is the 13,344,048-byte XZ file distributed with [A shorter superpermutation on fourteen symbols](https://github.com/aistaralchemist-cyber/superpermutation-bounds-2026/blob/cd6a1bd4609e5ee4fbff74eac99bfd58fe63c6aa/W-0166.detour). The replay checks the compressed and uncompressed token SHA-256 values, uses about 400 MiB of temporary disk and never materializes the 93.9-billion-letter word. To reuse an already decompressed file add `--tokens /path/to/word.tokens`. The same SHA checks apply.

`count_tokens.cpp` reads all Detour events. It enforces one initial START, the standard starting permutation, no intervening START or literal, a terminated stream and the published decoded-word digest in the trailer. For each event, `run_count.hpp` computes the binary sequence indicating which emitted positions end in a permutation, exploiting relabelling symmetry. Its composition rule for two binary strings merges the first string's final run with the second string's initial run. The full-stream replay checks the total length, number of permutation windows and number of 15-window runs. No assumption about the total number of such runs enters the computation.

The eligible event is a triple of consecutive explicit moves, each coded 6 or 10 with default count g below 65,536. The middle code is 10 and its default count is 13 modulo 14. Give each event tag 2g+1 for code 6 and 2g+2 for code 10. Interpret the three tags as successive digits in base 2¹⁸. A key's multiplicity is its total over the actual token stream. Keys are ranked in descending order of (multiplicity, key). Relabel the current permutation at entry to the triple to 0123456789ABCD. This relabelling preserves every subsequent relative move and therefore reconstructs the literal local factor up to symbol names.

`extract.py` decodes each of the 1,298 triples, tests every 14-window, and identifies the unique run of 15 windows. It explicitly checks that the last window of that run ends at the first letter of the middle explicit move. Thus two different counted event centers cannot refer to the same 15-window run. The local factor reaches up to four (or eight) adjacent runs on each side of the center within this triple; both the initial and final 14-letter windows are fixed. At triple boundaries the reported runs are local to the triple.

The census groups normalized literal factors by **exact byte equality** after relabelling the first endpoint to 0123456789ABCD. SHA-256 values in the tables identify the strings for interchange. The `interior_occurrences` column counts centers for which both outermost runs are strictly internal to the three-event factor. The shapes cover 19,861,497 distinct centers among 19,861,787 global 15-window runs.

| Radius | Runs in cropped factor | Keys | Occurrences |
|---:|---:|---:|---:|
| 4 | 7 | 1 | 2,395 |
| 4 | 8 | 1 | 2,691 |
| 4 | 9 | 1,296 | 19,856,411 |
| 8 | 11 | 1 | 2,395 |
| 8 | 12 | 1 | 2,691 |
| 8 | 13 | 2 | 2,649 |
| 8 | 14 | 2 | 6,447 |
| 8 | 15 | 3 | 3,471 |
| 8 | 16 | 5 | 5,855 |
| 8 | 17 | 1,284 | 19,837,989 |

The 24 highest-frequency triples have one common literal radius-eight word after relabelling and have 17,637,033 occurrences. The complete census finds 606 triples at 19,802,957 distinct centers with that identical 268-letter word. The factor has 238 distinct internal permutations, and all 19,802,957 occurrences contain 17 consecutive full global runs. The 9 and 33 literal radius-four and radius-eight word shapes appear in `shapes9.tsv` and `shapes17.tsv`.

`catalogue.tsv` links every original event triple to its multiplicity, both run counts and both normalized-word identifiers. `instances17.tsv` gives the 24 selected run descriptions before endpoint relabelling. Each row has the key, occurrence count, zero-based center run index in the full triple, original displacement (length minus 14), both fixed endpoints, then initial window and size of each local run. The SAT inputs are checked against these rows.

For every distinct radius-four word, `duals9.json` contains integral assignment potentials and an actual perfect matching. Source-side rows are the lexicographically sorted required permutations excluding the terminal window. Target-side columns exclude the initial window. `check_duals.py` extracts the requirements directly from the literal factor, verifies every nonloop inequality u[i]+v[j] ≤ displacement(i,j), checks a matching attaining the dual objective, and checks that this value equals the original displacement. The nine certificates cover every radius-four case through exact relabelling. The checker uses only Python's standard library. Rebuild the certificates with

```sh
python3 motifs/make_duals.py motifs/shapes9.tsv new-duals.json
python3 motifs/check_duals.py motifs/shapes9.tsv new-duals.json
```

The compressed Detour record was obtained from the author-posted W-0166 supplement, the word is a derivative of Jakub Halfar's W-0165, and the source carries CC BY 4.0. [Almanac W-0166](https://superpermutations.com/w/W-0166) · [Detour specification](https://superpermutations.com/docs/format)
