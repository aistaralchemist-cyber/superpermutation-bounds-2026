# Local optimality of the fourteen-symbol superpermutation W-0166

Jaehun Jung · Independent Researcher, Republic of Korea · 25 November 2026

The [paper](w0166-local-optimality.pdf) and its [TeX source](w0166-local-optimality.tex) concern the shortest possible replacements of specified intervals of a known covering word. Each replacement must preserve the first and last 14 letters and cover all distinct permutation windows present inside the original interval.

| Original neighborhoods | Checked result |
|---|---|
| At most nine runs, with the triple-boundary convention | At 19,861,497 centers, the source interval has minimum length. Nine normalized words and nine exact assignment certificates cover the 1,298 token types. |
| Seventeen complete runs, 24 most frequent qualifying token types | At 17,637,033 centers, the minimum is exactly 268 letters. |
| Every qualifying token type having that same normalized 268-letter factor | The seventeen-run result covers 606 types and 19,802,957 centers. The preceding 24 types are included. |

## Offline verification

Unzip the supplement and run this command inside the directory containing this README.

~~~sh
python3 verify.py
~~~

The full replay needs Python with the standard library and XZ support, C and C++17 compilers, and approximately 0.5 GB of temporary disk space. The scripts were run on macOS. They accept the usual CC and CXX executable settings for the compilers. The checks take the input, proofs and checker sources from this directory.

1. The [motif verifier](verification/motifs/README.md) reads the pinned Detour archive, reconstructs the type multiplicities and literal normalized factors, and checks the nine perfect matchings and integer duals.
2. The [independent semantic audit](verification/independent/README.md) scans the source intervals, verifies their endpoints, recalculates the literal overlap costs and the matching of value 250, checks the reduced-cost budget, checks all 15 internal cuts, and reconstructs every DIMACS clause for every input. It also performs a Python replay of the positive-hint LRAT proofs.
3. The [SAT verification guide](verification/sat/README.md) identifies the two external proof checkers, their pinned upstream source and regeneration commands. Each of the 24 types has its own description, archived CNF and archived LRAT. Numbering the same normalized problem by first occurrence produces byte-identical formulas and proofs. Both checkers also reject a deliberately incomplete control.

The distribution contains the full certified inputs, including the three-token [catalogue](verification/motifs/catalogue.tsv), [twenty-four input intervals](verification/motifs/instances17.tsv), the [case-level certificates](verification/sat/cases/) and [verification output](verification/full-replay.log). The raw SHA-256 checksums of the common uncompressed files are listed in the SAT guide. SHA256SUMS at archive root lists the distributed files.

## Data and contributions

[W-0166](https://superpermutations.com/w/W-0166) was derived by Jaehun Jung from Jakub Halfar’s [W-0165](https://superpermutations.com/w/W-0165). The earlier paper documents the 627-letter shortening, the resulting length and full permutation coverage. The present study proves fixed-endpoint local lower bounds for the constructed word. The canonical Detour record is reproduced under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). [Earlier paper and archive](https://github.com/aistaralchemist-cyber/superpermutation-bounds-2026/tree/cd6a1bd4609e5ee4fbff74eac99bfd58fe63c6aa)

Jaehun Jung directed the research. OpenAI Codex developed the added arguments and software, ran the verifications, and drafted this manuscript under his direction. The external LRAT checker sources retain the licenses in their respective directories.
