"""Replay the W-0166 census, local certificates, CNF bridges and LRAT proofs."""
from pathlib import Path
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    checks = [
        ("Recover the neighborhoods from W-0166 and check the assignment witnesses",
         ["verification/motifs/replay.py", "verification/data/W-0166.detour"]),
        ("Reconstruct every clause and replay the ordered RUP steps",
         ["verification/independent/audit_formulas.py", "--with-proofs"]),
        ("Replay the archived CNFs and LRAT proofs with both external checkers",
         ["verification/sat/verify_proofs.py"]),
    ]
    for title, command in checks:
        print(title, flush=True)
        subprocess.run([sys.executable, "-B", *command], cwd=root, check=True)
    print("PASS: corpus, nine dual certificates and all 24 case-level CNF/LRAT replays.")


if __name__ == "__main__":
    main()
